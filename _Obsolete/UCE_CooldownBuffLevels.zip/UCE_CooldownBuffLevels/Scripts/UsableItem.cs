using System.Text;
using UnityEngine;

public abstract partial class UsableItem : ScriptableItem
{
    [Header("Usage")]
    public int minLevel;

    [Header("Cooldown Buff")]
    public TargetBuffSkill cooldownBuff;
    public int cooldownLevel = 1;														// Fhiz

    public virtual bool CanUse(Player player, int inventoryIndex)
    {
        return
#if _iMMOUSAGEREQUIREMENTS
                UCE_CanUse(player) &&                                                   // Fhiz - UCE_CanUse - requires UsageRestrictions
#endif
                player.level >= minLevel &&
               (cooldownBuff == null ||
                player.GetBuffIndexByName(cooldownBuff.name) == -1);
    }

    public virtual void Use(Player player, int inventoryIndex)
    {
        if (cooldownBuff != null)
        {
            Entity oldTarget = player.target;
            player.target = player;
            cooldownBuff.Apply(player, Mathf.Max(1, cooldownLevel));					// Fhiz
            player.target = oldTarget;
        }
    }

    public virtual void OnUsed(Player player)
    {
    }

    public override string ToolTip()
    {
        StringBuilder tip = new StringBuilder(base.ToolTip());
        tip.Replace("{MINLEVEL}", minLevel.ToString());
        tip.Replace("{COOLDOWNLEVEL}", cooldownLevel.ToString());						// Fhiz
        return tip.ToString();
    }
}
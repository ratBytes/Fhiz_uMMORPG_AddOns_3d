// =======================================================================================
// Created and maintained by Fhiz
// Usable for both personal and commercial projects, but no sharing or re-sale
// * Discord Support Server.............: https://discord.gg/YkMbDHs
// * Public downloads website...........: https://www.indie-mmo.net
// * Pledge on Patreon for VIP AddOns...: https://www.patreon.com/IndieMMO
// =======================================================================================
using UnityEngine;
using Mirror;

// =======================================================================================
// PROJECTILE IMPACT SKILL EFFECT
// =======================================================================================
public class ProjectileImpactSkillEffect : ProjectileSkillEffect {

    public GameObject[] impactObjects;
	[Tooltip("[Optional] Select a tag that act as wall and stops the projectile")]
	public string wallTag;

    [Header("-=-=-=- Buff on Target -=-=-=-")]
    public BuffSkill applyBuff;
	public int buffLevel;
	[Range(0,1)]public float buffChance;
	
	protected int index;
	
	// -----------------------------------------------------------------------------------
	// Start
	// -----------------------------------------------------------------------------------
    void Start() {
    	
    	if (target != null && caster != null)
        {
            transform.position = caster.effectMount.position;
            transform.LookAt(target.collider.bounds.center);
        }
    	
    	index = 0;
    	
    	if (impactObjects.Length > 1) {
        
			float[] f = new float[impactObjects.Length];

			for ( int i = 0; i < impactObjects.Length; i++ )
				f[i] = impactObjects[i].GetComponent<UCE_WeightedObject>().chance;

			index = UCE_Tools.WeightedRandomIndex(f);

		}
    
    	FixedUpdate();
    }
    
	// -----------------------------------------------------------------------------------
	// checkWall
	// -----------------------------------------------------------------------------------
	protected void checkWall() {
		
		if (isServer && wallTag != "") {
		
			Ray ray = new Ray(transform.position, transform.forward);
			RaycastHit hit;

			if (Physics.Raycast(ray, out hit, 0.25f)) { 
			   if (hit.collider.tag == wallTag) {
					GameObject impactObject = impactObjects[index];
					GameObject go = Instantiate(impactObject.gameObject, transform.position, transform.rotation);
					NetworkServer.Spawn(go);
					NetworkServer.Destroy(gameObject);
				}
			}
		}
            
	}
	
	// -----------------------------------------------------------------------------------
	// FixedUpdate
	// -----------------------------------------------------------------------------------
    void FixedUpdate() {
    
        if (target != null && caster != null) {
			
			checkWall();
            
            Vector3 goal = target.collider.bounds.center;
            transform.position = Vector3.MoveTowards(transform.position, goal, speed);
            transform.LookAt(goal);

            // server: reached it? apply skill and destroy self
            if (isServer && transform.position == goal) {
            
                if (target.health > 0) {
                    caster.DealDamageAt(target, caster.damage + damage);
                	target.UCE_ApplyBuff(applyBuff, buffLevel, buffChance);
                }
                
                GameObject impactObject = impactObjects[index];
        
        		if (impactObject != null) {
            		GameObject go = Instantiate(impactObject.gameObject, transform.position, transform.rotation);
            		NetworkServer.Spawn(go);
        		}
        		else Debug.LogWarning(name + ": missing impact gameobject");
                
                NetworkServer.Destroy(gameObject);
            }
        }
        else if (isServer) NetworkServer.Destroy(gameObject);
    }
    
    // -----------------------------------------------------------------------------------
    
}

// =======================================================================================
﻿using UnityEngine;

// =======================================================================================
// ENTITY EFFECTS
// =======================================================================================
public partial class UCE_EntityEffects : MonoBehaviour
{
    public GameObject parent;
    public GameObject[] spawnEffects;
    public GameObject[] destroyEffects;

    protected bool isQuitting = false;
    protected bool isDestroyed = false;

    // -----------------------------------------------------------------------------------
    //
    // -----------------------------------------------------------------------------------
    private void OnApplicationQuit()
    {
        isQuitting = true;
    }

    // -----------------------------------------------------------------------------------
    //
    // -----------------------------------------------------------------------------------
    private void Awake()
    {
        if (spawnEffects.Length > 0 && parent != null)
        {
            foreach (GameObject spawnEffect in spawnEffects)
                Instantiate(spawnEffect, parent.transform.position, Quaternion.identity);
        }
    }

    // -----------------------------------------------------------------------------------
    //
    // -----------------------------------------------------------------------------------
    public void OnDeath()
    {
        if (!isQuitting && !isDestroyed && destroyEffects.Length > 0 && parent != null)
        {
            foreach (GameObject destroyEffect in destroyEffects)
                Instantiate(destroyEffect, parent.transform.position, Quaternion.identity);

            isDestroyed = true;
        }
    }

    // -----------------------------------------------------------------------------------
}

// =======================================================================================
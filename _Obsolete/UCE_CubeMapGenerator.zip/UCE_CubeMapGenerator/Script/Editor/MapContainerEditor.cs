
using UnityEngine;
using UnityEditor;

[CustomEditor(typeof (MapContainer))]
public class MapContainerEditor : Editor 
{

    //override the original Inspector with our own one:
    public override void OnInspectorGUI()
	{
	
	    //store the object the original Inspector belongs to as GenerateTerrain in a variable of the same type:
	    MapContainer map = (MapContainer)target;
    	DrawDefaultInspector ();

        if (GUILayout.Button("Generate & Save Prefab")) {
           	map.Generate();
        }
            
    }
}

﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// -----------------------------------------------------------------------------------
// MapObject
// -----------------------------------------------------------------------------------
[CreateAssetMenu(menuName="MapGenerator/New MapObject", order=999)]
public class MapObject: ScriptableObject
{
    
    public int maxObjects = 99;
    [Range(0,1)]public float baseSpawnChance = 0.5f;
    
    public GameObject[] high;
    public GameObject[] medium;
    public GameObject[] low;
    public GameObject[] lowest;
     
    // -----------------------------------------------------------------------------------
    // Get
    // -----------------------------------------------------------------------------------
    public GameObject Get {
    	get {
    		return medium[0];
    	}
    }
    
    // -----------------------------------------------------------------------------------
    // GetAlt
    // -----------------------------------------------------------------------------------
   	public GameObject GetAlt(int alt, int maxAlt) {
    	
		if (alt <= 0 && lowest.Length > 0) {
			return lowest[UnityEngine.Random.Range(0, lowest.Length)];				// lowest
			
		} else if (alt < maxAlt/2 && low.Length > 0) {
			return low[UnityEngine.Random.Range(0, low.Length)];					// low
		
		} else if (alt >= maxAlt/2 && alt <= maxAlt/2 && medium.Length > 0) {		// medium
			return medium[UnityEngine.Random.Range(0, medium.Length)];
			
		} else if (alt > maxAlt/2 && high.Length > 0) {
			return high[UnityEngine.Random.Range(0, high.Length)];					// high
				
		}
	
    	return null;
    	
    }
  	
  	// -----------------------------------------------------------------------------------
   
}

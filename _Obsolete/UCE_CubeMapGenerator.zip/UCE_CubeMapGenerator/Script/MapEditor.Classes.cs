using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using System.IO;

[System.Serializable]
public class TerrainCubes {
	public MapObject surface;
   	public MapObject underground;
}
	
[System.Serializable]
public class TerrainDoodats {
	public MapObject[] doodatsGround;
}
﻿
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

// ---------------------------------------------------------------------------------------
// MapData
// ---------------------------------------------------------------------------------------
[System.Serializable]
public class MapData {

	private struct Fleck {

		public int A, B;
		public bool IsEdge;

		public Fleck (int a, int b) {
			A = a;
			B = b;
			IsEdge = false;
		}

		public static Fleck Lerp (Fleck a, Fleck b, float t) {
			return new Fleck(
				(int)Mathf.Lerp(a.A, b.A, t),
				(int)Mathf.Lerp(a.B, b.B, t)
			);
		}

		public static float Distance (Fleck a, Fleck b) {
			return Vector2.Distance(new Vector2(a.A, a.B), new Vector2(b.A, b.B));
		}

	}

	const int MAX_BRIDGE_COUNT = 400;
	const float BUMP_MUTI = 0.3f;
	public const int MIN_MOUNTAIN_HEIGHT = 1;
	public const int MAX_MOUNTAIN_HEIGHT = 9;
	public const int MIN_NODE_SIZE = 8;
	public const int MAX_NODE_SIZE = 64;

	public string name = "New Map";
	
	public MapContainer map;
	
	public int maxBirthPointNumA 		= 99;
	public int maxDoodatsGround 		= 9999;
	public int maxTerrainConnections 	= 9999;
	
	bool reverseSpawn = false;
	float spawnChance = 0;
	
	int cCubes						= 0;
	int cDoodats					= 0;
	int cConnections 				= 0;
	
	GameObject root;
	int[] data;
	int[] biomes;
	bool[,,] doodats;
	GameObject[,,] cubes;
	GameObject[,,] connections;
	int nodeWidth;
	int nodeHeight;
	List<Vector2> birthPointsA = new List<Vector2>();
	List<Vector2> doodatsGround = new List<Vector2>();
	List<Vector2> doodatsWater = new List<Vector2>();
	List<GameObject> nodes = new List<GameObject>();
	
	public int this[int x, int y] {
		get {
			return data[y * map.width + x];
		}
		set {
			data[y * map.width + x] = value;
		}
	}
	
	public float GenerationComplexity {
		get {
			return map.threshold * map.width * map.height * map.iteration;
		}
	}
	
	public float[] GetRandomSeeds () {
		float[] seeds = new float[map.width * map.height];
		for (int i = 0; i < map.width; i++) {
			for (int j = 0; j < map.height; j++) {
				seeds[j * map.width + i] = Random.value;
			}
		}
		return seeds;
	}

	public float[] GetSmoothRandomSeeds (float bump) {
		float[] seeds = new float[map.width * map.height];
		float randomOffsetX = Random.value * map.width;
		float randomOffsetY = Random.value * map.height;
		for (int i = 0; i < map.width; i++) {
			for (int j = 0; j < map.height; j++) {
				seeds[j * map.width + i] = Mathf.PerlinNoise(
					i * bump * BUMP_MUTI + randomOffsetX,
					j * bump * BUMP_MUTI + randomOffsetY
				);
			}
		}
		return seeds;
	}

	public bool Generate (System.Action<float> progressCallback = null) {
		return Generate(GetRandomSeeds(), progressCallback);
	}

	// -----------------------------------------------------------------------------------
	// Generate
	// -----------------------------------------------------------------------------------
	public bool Generate (float[] seeds, System.Action<float> progressCallback = null) {

		if (seeds.Length < map.width * map.height) {
			return false;
		}
		
		biomes 			= new int[map.width * map.height];
		data 			= new int[map.width * map.height];
		doodats 		= new bool[map.width+1, map.height+1, map.altitude+2];
		cubes 			= new GameObject[map.width+1, map.height+1, map.altitude+2];
		connections		= new GameObject[map.width+1, map.height+1, map.altitude+2];
		
		int[] biomeData = new int[map.width * map.height];
		int[] tempData = new int[map.width * map.height];
		
		
		// Default null
		for (int x = 0; x < map.width+1; x++) {
			for (int y = 0; y < map.height+1; y++) {
				for (int z = 0; z < map.altitude+2; z++) {
					cubes[x,y,z] = null;
					connections[x,y,z] = null;
					doodats[x,y,z] = false;
				}
			}
		}
		
		// Init by seed
		for (int i = 0; i < map.width; i++) {
			for (int j = 0; j < map.height; j++) {
				int seedData = (int)(seeds[j * map.width + i] * (2f - 0.0001f));
				tempData[j * map.width + i] = seedData;
			}
		}

		// Close Edge
		if (map.edge > 0) {
			for (int i = 0; i < map.width; i++) {
				for (int j = 0; j < map.height; j++) {
					if (i < map.edge || i > map.width - 1 - map.edge || j < map.edge || j > map.height - 1 - map.edge) {
						tempData[j * map.width + i] = 0;
					}
				}
			}
		}

		// Copy to Data
		tempData.CopyTo(data, 0);

		// map.iteration
		float iterRadius = map.threshold * 0.25f + 1f;
		int groundCount = 0;
		for (int iter = 0; iter < map.iteration; iter++) {
			// SetData
			if (iter != map.iteration - 1) {
				// Loop
				for (int i = 0; i < map.width; i++) {
					for (int j = 0; j < map.height; j++) {
						tempData[j * map.width + i] = IterateFleck(i, j, iterRadius);
					}
				}
			} else {
				// Last Loop
				for (int i = 0; i < map.width; i++) {
					for (int j = 0; j < map.height; j++) {
						int fleck = IterateFleck(i, j, iterRadius);
						if (fleck == 1) {
							groundCount++;
						}
						tempData[j * map.width + i] = fleck;
					}
				}
			}
			tempData.CopyTo(data, 0);
			// Callback
			if (progressCallback != null) {
				progressCallback((iter + 1f) / (map.iteration + 1f));
			}
		}

		// Bridge and BirthPoint
		BridgeAndBirthPoint(groundCount);
		
		// Biomes
		if (map.terrainCubes.Length > 0) {
			float[] altSeedb = GetSmoothRandomSeeds(map.bump);
			for (int i = 0; i < map.width; i++) {
				for (int j = 0; j < map.height; j++) {
					int alt = 0;
					if (data[j * map.width + i] != 0) {
						//alt = (int)(altSeedb[j * map.width + i] * map.terrainCubes.Length-1);
						alt = getRandomIndex(altSeedb[j * map.width + i], map.terrainCubes.Length-1);
					}
					biomeData[j * map.width + i] = Mathf.Clamp(alt,0, map.terrainCubes.Length-1);
				}
			}
		}
		biomeData.CopyTo(biomes, 0);
		
		// Altitude
		if (map.altitude > 0) {
			float[] altSeed = GetSmoothRandomSeeds(map.bump);
			for (int i = 0; i < map.width; i++) {
				for (int j = 0; j < map.height; j++) {
					int alt = 0;
					if (data[j * map.width + i] != 0) {
						alt = (int)(altSeed[j * map.width + i] * (map.altitude - 1f + 0.999f)) + 1;
					}
					tempData[j * map.width + i] = alt;
				}
			}
		}
		tempData.CopyTo(data, 0);

		return true;
	}
	
	// -----------------------------------------------------------------------------------
	// getRandomIndex
	// -----------------------------------------------------------------------------------
	public int getRandomIndex(float fRandom, int nEntries) {
		return Mathf.RoundToInt(fRandom / (1 / nEntries));
	}

	// -----------------------------------------------------------------------------------
	// getRandomSpawnPosition
	// -----------------------------------------------------------------------------------
	public Quaternion getRandomSpawnRotation() {
		return Quaternion.Euler(new Vector3(0, Random.Range(0, 360), 0));
	}
	
	// -----------------------------------------------------------------------------------
	// getRandomCubeRotation
	// -----------------------------------------------------------------------------------
	public Quaternion getRandomCubeRotation() {
		float rot = UnityEngine.Random.Range(0,3) * 90;
		return Quaternion.Euler(new Vector3(0, rot, 0));
	}
	
	// -----------------------------------------------------------------------------------
	// getNode
	// -----------------------------------------------------------------------------------
	public GameObject getNode(int x, int y, int nodeWidth) {
		int w 	= (int)Mathf.Floor(x / map.nodeSize);
		int h 	= (int)Mathf.Floor(y / map.nodeSize);
		int idx = w + (nodeWidth * h);
		return nodes[idx];
	}
	
	// -----------------------------------------------------------------------------------
	// GenerateStats
	// -----------------------------------------------------------------------------------
	public void GenerateStats() {
	
		nodeWidth 	= map.width / map.nodeSize;
		nodeHeight 	= map.height / map.nodeSize;
		
		maxBirthPointNumA 		= nodeWidth * 3;
		maxTerrainConnections 	= map.width * map.height;
		maxDoodatsGround 		= map.width * map.height;
		
		cCubes 					= 0;
		cDoodats 				= 0;
		cConnections 			= 0;
		
	}
	
	// -----------------------------------------------------------------------------------
	// GenerateRoot
	// -----------------------------------------------------------------------------------
	public void GenerateRoot() {
		root = new GameObject();
		root.transform.position = Vector3.zero;
		root.transform.rotation = Quaternion.identity;
		root.transform.localScale = map.tileSize * Vector3.one;
	}
	
	// -----------------------------------------------------------------------------------
	// GenerateNodes
	// -----------------------------------------------------------------------------------
	public void GenerateNodes() {
		
		nodes.Clear();
		
		for (int i = 0; i < nodeWidth; i++) {
			for (int j = 0; j < nodeHeight; j++) {
				
				float correctedX = i * map.tileSize;
				float correctedY = j * map.tileSize;
				float correctedZ = 0;
				
				GameObject g = new GameObject();
				
				g.name = "node_" + i + "_" + j;
				g.transform.SetParent(root.transform);
				g.transform.localScale = Vector3.one;
				g.AddComponent<UCE_DistanceChecker>();
				
				g.transform.localPosition = new Vector3(
					correctedX,
					correctedZ,
					correctedY
				);
				
				nodes.Add(g);
				
			}
		}
	
	}
	
	// ================================= CHECK FUNCTIONS ===================================

	// -----------------------------------------------------------------------------------
	// getConnectionFacing
	// checks if a connection can be made and returns its facing direction if so
	// -----------------------------------------------------------------------------------
	public bool getConnectionFacing(int x, int y, int z) {
		
		if (z == 0 || x == 0 || y == 0 || checkCubesZ(x,y,z) == 0 || checkCubesZ(x,y,z) >= 8 || checkConnectionsZ(x,y,z) != 0 ) return false;
		
		List<float> facings = new List<float>();
		
		// -- WEST
		if (checkFacing(x,y,z, -1, 0))
			return true;
				
		// -- EAST
		if (checkFacing(x,y,z, +1, 0))
			return true;
		
		// -- NORTH
		if (checkFacing(x,y,z, 0, +1))
			return true;
		
		// -- SOUTH
		if (checkFacing(x,y,z, 0, -1))
			return true;
		
		return false;
		
	}
	
	// -----------------------------------------------------------------------------------
	// checkFacing
	// -----------------------------------------------------------------------------------
	public bool checkFacing(int x, int y, int z, int dirX, int dirY) {
		
		return 
				(
				checkConnectionsZ(x,y,z+1) == 0 &&							// no connection on higher spot
				checkConnectionsZ(x,y,z) == 0 &&							// no connection on same spot
				checkConnectionsZ(x,y,z-1) == 0 &&							// no connection on lower spot
				checkConnectionsZ(x+dirX,y+dirY,z) == 0 &&					// no connection on target spot
				checkConnectionsZ(x+(dirX*2),y+(dirY*2),z) == 0 &&			// no connection around the target spot
				checkConnectionsZ(x+dirX,y+dirY,z-1) == 0 &&				// no connection below target spot
				checkConnectionsZ(x+dirX,y+dirY,z+1) == 0 &&				// no connection above target spot
				checkCubesZ(x,y,z,0,true) > 1 &&
				checkCubesZ(x,y,z,0) < 6 &&
				checkCubesZ(x+dirX,y+dirY,z, 0, true) > 1 &&
				cubes[x+dirX,y+dirY,z] != null	&&							// target spot must not be empty
				cubes[x+dirX,y+dirY,z+1] == null	&&						// above target spot must be empty
				cubes[x+(dirX*-1),y+(dirY*-1),z] == null &&					// behind spot must be empty
				cubes[x+(dirX*-1),y+(dirY*-1),z-1] != null					// lower behind spot must not be empty	
				);
	
	}
	
	// -----------------------------------------------------------------------------------
	// checkCubesZ
	// return number of neighbours on the same z axis
	// -----------------------------------------------------------------------------------
	public int checkCubesZ(int x, int y, int z, int zModifier=0, bool fourDir = false) {
		
		if (z == 0 || x == 0 || y == 0 || x > map.width || y > map.height) return 0;
		
		int n = 0;
		
		if (cubes[x-1,	y,		z-zModifier] != null) 	n++; 		// west
		if (cubes[x+1,	y,		z-zModifier] != null) 	n++; 		// east

		if (cubes[x,	y-1,	z-zModifier] != null) 	n++; 		// south
		if (cubes[x,	y+1,	z-zModifier] != null) 	n++; 		// north
		
		if (fourDir)
			return n;
		
		if (cubes[x-1,	y-1,	z-zModifier] != null) 	n++; 		// south-east
		if (cubes[x-1,	y+1,	z-zModifier] != null) 	n++; 		// north-east
	
		if (cubes[x+1,	y-1,	z-zModifier] != null) 	n++; 		// south-west
		if (cubes[x+1,	y+1,	z-zModifier] != null) 	n++; 		// north-west
		
		return n;
	
	}
	
	// -----------------------------------------------------------------------------------
	// checkConnectionsZ
	// return number of neighbours on the same z axis
	// -----------------------------------------------------------------------------------
	public int checkConnectionsZ(int x, int y, int z, int zModifier=0) {
		
		if (z == 0 || x == 0 || y == 0 || x > map.width || y > map.height) return 0;
		
		int n = 0;
		
		if (connections[x-1,	y,		z-zModifier] != null) 	n++; 		// east
		if (connections[x+1,	y,		z-zModifier] != null) 	n++; 		// west
		if (connections[x,		y-1,	z-zModifier] != null) 	n++; 		// south
		if (connections[x,		y+1,	z-zModifier] != null) 	n++; 		// north
		if (connections[x-1,	y-1,	z-zModifier] != null) 	n++; 		// south-east
		if (connections[x-1,	y+1,	z-zModifier] != null) 	n++; 		// north-east
		if (connections[x+1,	y-1,	z-zModifier] != null) 	n++; 		// south-west
		if (connections[x+1,	y+1,	z-zModifier] != null) 	n++; 		// north-west
		
		return n;
	
	}
	
	// -----------------------------------------------------------------------------------
	// checkDoodatsZ
	// return number of neighbours on the same z axis
	// -----------------------------------------------------------------------------------
	public int checkDoodatsZ(int x, int y, int z, int zModifier=0) {
		
		if (z == 0 || x == 0 || y == 0 || x > map.width || y > map.height) return 0;
		
		int n = 0;
		
		if (doodats[x-1,	y,		z-zModifier] ) 	n++; 		// east
		if (doodats[x+1,	y,		z-zModifier] ) 	n++; 		// west
		if (doodats[x,		y-1,	z-zModifier] ) 	n++; 		// south
		if (doodats[x,		y+1,	z-zModifier] ) 	n++; 		// north
		if (doodats[x-1,	y-1,	z-zModifier] ) 	n++; 		// south-east
		if (doodats[x-1,	y+1,	z-zModifier] ) 	n++; 		// north-east
		if (doodats[x+1,	y-1,	z-zModifier] ) 	n++; 		// south-west
		if (doodats[x+1,	y+1,	z-zModifier] ) 	n++; 		// north-west
		
		return n;
	
	}
	
	// -----------------------------------------------------------------------------------
	// checkSurface
	// -----------------------------------------------------------------------------------
	public bool checkSurface(int z, int alt) {
		return (z == alt);
	}
	
	// -----------------------------------------------------------------------------------
	// checkUnderground
	// -----------------------------------------------------------------------------------
	public bool checkUnderground(int z) {
		return (z != 0);
	}
	
	// -----------------------------------------------------------------------------------
	// checkDoodat
	// -----------------------------------------------------------------------------------
	public bool checkDoodat(int x, int y, int z) {
		return doodats[x,y,z];
	}

	// -----------------------------------------------------------------------------------
	// checkConnection
	// -----------------------------------------------------------------------------------
	public bool checkConnection(int x, int y, int z) {
		return connections[x,y,z] != null;
	}
	
	// -----------------------------------------------------------------------------------
	// checkCube
	// -----------------------------------------------------------------------------------
	public bool checkCube(int x, int y, int z) {
		return cubes[x,y,z] != null;
	}
	
	// -----------------------------------------------------------------------------------
	// checkCubes
	// checks all surrounding cubes
	// -----------------------------------------------------------------------------------
	public bool checkCubes(int x, int y, int z) {
		if (x < 0 || y < 0 || z < 0) return false;
		return 	
				(x == 0 				|| x > 0 				&& cubes[x-1,y,z] != null) &&
				(x == map.width-1 		|| x < map.width-1 		&& cubes[x+1,y,z] != null) &&
				(y == 0 				|| y > 0 				&& cubes[x,y-1,z] != null) &&
				(y == map.height-1 		|| y < map.height-1 	&& cubes[x,y+1,z] != null) &&
				(z == 0 				|| z > 0				&& cubes[x,y,z-1] != null) &&
				(z == map.altitude-1 	|| z < map.altitude-1 	&& cubes[x,y,z+1] != null)
				;
	}
	
	// ================================= SET FUNCTIONS ===================================
	
	// -----------------------------------------------------------------------------------
	// setCube
	// -----------------------------------------------------------------------------------
	public void setCube(int x, int y, int z, GameObject go) {
		cubes[x,y,z] = go;
		cCubes++;
	}
	
	// -----------------------------------------------------------------------------------
	// setDoodat
	// -----------------------------------------------------------------------------------
	public void setDoodat(int x, int y, int z) {
		doodats[x,y,z] = true;
		cDoodats++;
	}
	
	// -----------------------------------------------------------------------------------
	// setConnection
	// -----------------------------------------------------------------------------------
	public void setConnection(int x, int y, int z, GameObject go) {
		connections[x,y,z] = go;
		cConnections++;
	}
	
	// -----------------------------------------------------------------------------------
	// getSpawnChance
	// -----------------------------------------------------------------------------------
	public bool getSpawnChance(float chance = 0.5f) {
		
		if (reverseSpawn)
			spawnChance -= 0.05f;
		else
			spawnChance += 0.05f;
		
		if (spawnChance >= chance)
			reverseSpawn = true;
		else if (spawnChance <= (chance/2)*-1)
			reverseSpawn = false;
		
		return UnityEngine.Random.value <= spawnChance;

	}
	
	// ================================ SPAWN FUNCTIONS ==================================

	// -----------------------------------------------------------------------------------
	// SpawnAnchor
	// -----------------------------------------------------------------------------------
	public void SpawnAnchor(int x, int y, int z, int alt) {
		
		if (z == 1) {
						
			if (getNode(x,y,nodeWidth).GetComponent<UCE_DistanceChecker>().centerObject == null) {
			
				GameObject a = new GameObject();
				a.name = "_anchor";
				a.transform.SetParent(getNode(x,y,nodeWidth).transform);
				a.transform.localPosition = new Vector3(
						x * map.tileSize,
						z * map.tileSize,
						y * map.tileSize
					);
				a.transform.localScale = Vector3.one;
			
				getNode(x,y,nodeWidth).GetComponent<UCE_DistanceChecker>().centerObject = a;
											
			}
				
		}
	
	}
	
	// -----------------------------------------------------------------------------------
	// SpawnTerrainCube
	// -----------------------------------------------------------------------------------
	public void SpawnTerrainCube(int x, int y, int z, int alt) {
	
		if (!checkCubes(x,y,z) && !checkCube(x,y,z) ) {
			
			GameObject source = null;
			
			int biomeIndex = biomes[y * map.width + x];

			if (checkSurface(z, alt)) {
				source = map.terrainCubes[biomeIndex].surface.GetAlt(alt, map.altitude);
			} else {
				source = map.terrainCubes[biomeIndex].underground.GetAlt(alt, map.altitude);
			}
						
			GameObject tmp = Object.Instantiate(source);
			tmp.name = "cube_" + x + "_" + y + "_" + z;
			tmp.transform.SetParent(getNode(x,y,nodeWidth).transform);
			tmp.transform.localPosition = new Vector3(
				x * map.tileSize,
				z * map.tileSize,
				y * map.tileSize
			);
			tmp.transform.localRotation = getRandomCubeRotation();
			tmp.transform.localScale = new Vector3(map.tileSize, map.tileSize, map.tileSize);
			setCube(x,y,z,tmp);
			
		}
							
	}
		
	// -----------------------------------------------------------------------------------
	// SpawnTerrainDoodat
	// -----------------------------------------------------------------------------------
	public bool SpawnTerrainDoodat(int x, int y, int z, int alt, MapObject mapObject, bool bBig = false) {
		
		if 
			(
			!checkDoodat(x,y,z) && 
			!checkConnection(x,y,z) && 
			checkSurface(z,alt) && 
			(!bBig || (bBig && checkCubesZ(x, y, z, 0, true) != 2)) &&					// big doodats are not placed on narrow bridges
			(!bBig || (bBig && checkDoodatsZ(x,y,z) <= 0)) &&									// big doodats may not have any other doodats around
			cDoodats < maxDoodatsGround
			) {
			
			if (mapObject && getSpawnChance(mapObject.baseSpawnChance)) {
				
				GameObject source = mapObject.GetAlt(alt, map.altitude);
				
				if (source == null) return false;
				
				GameObject g = Object.Instantiate(source);
				
				float correctedX = x * map.tileSize;
				float correctedY = y * map.tileSize;
				float correctedZ = (z * map.tileSize) + (map.tileSize*0.5f);
				
				g.name = "tmp_doodat_g_" + x + "_" + y + "_" + z;
				g.transform.SetParent(getNode(x,y,nodeWidth).transform);
				g.transform.localPosition = new Vector3(
					correctedX,
					correctedZ,
					correctedY
				);
				g.transform.localRotation = getRandomCubeRotation();
				g.transform.localScale = map.doodatSize * Vector3.one;

				setDoodat(x,y,z);
				return true;
			}
		
		}
		
		return false;
		
	}
	
	// -----------------------------------------------------------------------------------
	// SpawnTinyDoodat
	// spawns a 2x2 patch of tiny doodats
	// -----------------------------------------------------------------------------------
	public bool SpawnTinyDoodat(int x, int y, int z, int alt, MapObject mapObject) {
		
		if (
			!checkDoodat(x,y,z) && 
			!checkConnection(x,y,z) && 
			checkSurface(z,alt) && 
			cDoodats < maxDoodatsGround) {
			
			if (mapObject && getSpawnChance(mapObject.baseSpawnChance)) {
				
				GameObject source = mapObject.GetAlt(alt, map.altitude);
				
				if (source == null) return false;
				
				GameObject g;
				
				float correctedX = x * map.tileSize;
				float correctedY = y * map.tileSize;
				float correctedZ = (z * map.tileSize) - (map.tileSize*0.25f);
				
				int i = UnityEngine.Random.Range(1,4);
				int j = 0;
				
				for (int xx = -1; xx <= 1; xx++) {
					for (int yy = -1; yy <= 1; yy++) {
					
					if (j == i) break;
					if (xx == 0 || yy == 0) continue;
				
					correctedX = x * map.tileSize + (map.tileSize*0.25f)*xx;
					correctedY = y * map.tileSize + (map.tileSize*0.25f)*yy;
			
					g = Object.Instantiate(source);
					
					g.name = "tmp_doodat_g_" + x + "_" + y + "_" + z;
					g.transform.SetParent(getNode(x,y,nodeWidth).transform);
					g.transform.localPosition = new Vector3(
						correctedX,
						correctedZ,
						correctedY
					);
					g.transform.localRotation = getRandomCubeRotation();
					g.transform.localScale = map.doodatSize * Vector3.one;
			
					setDoodat(x,y,z);
					j++;
					
					}
				}
			
				return true;
			
			}
		
		}
		
		return false;
		
	}
	
	// -----------------------------------------------------------------------------------
	// SpawnTerrainConnection
	// -----------------------------------------------------------------------------------
	public bool SpawnTerrainConnection(int x, int y, int z, int alt) {
		
		if (
			checkSurface(z,alt) &&
			getConnectionFacing(x, y, z)
			) {
		
			int biomeIndex = Mathf.Max(0, biomes[y * map.width + x]-1);
			
			MapObject mapObject = map.terrainCubes[biomeIndex].surface;
				
			GameObject g;
			
			float correctedX = x * map.tileSize;
			float correctedY = y * map.tileSize;
			float correctedZ = (z * map.tileSize) - (map.tileSize*0.25f);
			
			for (int xx = -1; xx <= 1; xx++) {
				for (int yy = -1; yy <= 1; yy++) {
				
				if (xx == 0 || yy == 0) continue;
				
				correctedX = x * map.tileSize + (map.tileSize*0.25f)*xx;
				correctedY = y * map.tileSize + (map.tileSize*0.25f)*yy;
			
				g = Object.Instantiate(mapObject.GetAlt(alt, map.altitude));
				g.name = "tmp_connection_g_" + x + "_" + y + "_" + z;
				g.transform.SetParent(getNode(x,y,nodeWidth).transform);
				g.transform.localPosition = new Vector3(
					correctedX,
					correctedZ,
					correctedY
				);
				g.transform.localRotation = getRandomCubeRotation();
				g.transform.localScale = map.tileSize * 0.5f * Vector3.one;
			
				setConnection(x,y,z,g);
			
				}
			}
			
			return true;
			
		}
		
		return false;
		
	}

	// -----------------------------------------------------------------------------------
	// SpawnSpawnPoints
	// -----------------------------------------------------------------------------------
	public void SpawnSpawnPoints() {
		
		if (map.spawnPointA) {
			for (int i = 0; i < birthPointsA.Count; i++) {
				
				float correctedX = birthPointsA[i].x * map.tileSize;
				float correctedY = birthPointsA[i].y * map.tileSize;
				float correctedZ = (this[(int)birthPointsA[i].x, (int)birthPointsA[i].y] * map.tileSize) + (map.tileSize);
				
				GameObject g = Object.Instantiate(map.spawnPointA.Get);
				g.name = "SpawnPointA " + i;
				g.transform.SetParent(getNode((int)birthPointsA[i].x,(int)birthPointsA[i].y,nodeWidth).transform);
				g.transform.localPosition = new Vector3(
					correctedX,
					correctedZ,
					correctedY
				);
				g.transform.localRotation = Quaternion.identity;
				g.transform.localScale = map.tileSize * 0.5f * Vector3.one;
				
			}
		}
		
	}
	
	// ============================= SPAWN ALL FUNCTIONS =================================
	
	// -----------------------------------------------------------------------------------
	// SpawnTerrain
	// -----------------------------------------------------------------------------------
	public void SpawnTerrain() {
		
		// -- spawn cubes & anchors
		
		for (int x = 0; x < map.width; x++) {
			for (int y = 0; y < map.height; y++) {
			
				int alt = this[x, y];
				
				for (int z = 0; z <= alt; z++) {
					SpawnAnchor(x,y,z,alt);
					SpawnTerrainCube(x,y,z,alt);
				}
				
			}
		}
		
		// -- spawn stairs
		
		for (int x = 0; x < map.width; x++) {
			for (int y = 0; y < map.height; y++) {
			
				int alt = this[x, y];
				
				for (int z = 0; z <= alt; z++)
					SpawnTerrainConnection(x,y,z,alt);
				
			}
		}
		
		// -- now destroy all cubes that have stairs on them
		
		for (int x = 0; x < map.width; x++) {
			for (int y = 0; y < map.height; y++) {
			
				int alt = this[x, y];
				
				for (int z = 0; z <= alt; z++) {
					
					if (cubes[x,y,z] != null && connections[x,y,z] != null)
						Object.DestroyImmediate(cubes[x,y,z], false);
									
				}
			}
		}
	
	}

	// -----------------------------------------------------------------------------------
	// SpawnAllTerrainDoodats
	// -----------------------------------------------------------------------------------
	public void SpawnAllTerrainDoodats() {
		
		int ddc = 0;
		
		// -- Large Doodats
		
		for (int i = 1; i < map.width-1; i++) {															// -- X (not on border)
			for (int j = 1; j < map.height-1; j++) {													// -- Y (not on border)
		
				int alt = this[i, j];																	// -- Altitude
				int biomeIndex = biomes[j * map.width + i];												// -- Biome
				
				for (int k = 0; k <= alt; k++) {														// -- Z
					
					if (map.bigDoodats.Length <= 0) continue;
					
					foreach (MapObject mapObject in map.bigDoodats[biomeIndex].doodatsGround) {		// -- Variants
						
						if (mapObject == null) continue;
						
						spawnChance = mapObject.baseSpawnChance/2;
						
						if (ddc < mapObject.maxObjects) {
					
							if (SpawnTerrainDoodat(i,j,k,alt, mapObject, true)) {
								ddc++;
								break;
							}
							
						}
					
					}
		
				}
			}
		}
		
		// -- Small Doodats
		
		for (int i = 1; i < map.width-1; i++) {															// -- X (not on border)
			for (int j = 1; j < map.height-1; j++) {													// -- Y (not on border)
		
				int alt = this[i, j];																	// -- Altitude
				int biomeIndex = biomes[j * map.width + i];												// -- Biome
				
				for (int k = 0; k <= alt; k++) {														// -- Z
					
					if (map.smallDoodats.Length <= 0) continue;
					
					foreach (MapObject mapObject in map.smallDoodats[biomeIndex].doodatsGround) {		// -- Variants
						
						if (mapObject == null) continue;
						
						spawnChance = mapObject.baseSpawnChance/2;
						
						if (ddc < mapObject.maxObjects) {
					
							if (SpawnTerrainDoodat(i,j,k,alt, mapObject, false)) {
								ddc++;
								break;
							}
							
						}
					
					}
		
				}
			}
		}
		
		// -- Tiny Doodats
		
		for (int i = 1; i < map.width-1; i++) {															// -- X (not on border)
			for (int j = 1; j < map.height-1; j++) {													// -- Y (not on border)
		
				int alt = this[i, j];																	// -- Altitude
				int biomeIndex = biomes[j * map.width + i];												// -- Biome
				
				for (int k = 0; k <= alt; k++) {														// -- Z
					
					if (map.tinyDoodats.Length <= 0) continue;
					
					foreach (MapObject mapObject in map.tinyDoodats[biomeIndex].doodatsGround) {		// -- Variants
						
						if (mapObject == null) continue;
						
						spawnChance = mapObject.baseSpawnChance/2;
						
						if (ddc < mapObject.maxObjects) {
					
							if (SpawnTinyDoodat(i,j,k,alt, mapObject)) {
								ddc++;
								break;
							}
							
						}
					
					}
		
				}
			}
		}
		
	}
	
	// -----------------------------------------------------------------------------------
	// SpawnToScene
	// -----------------------------------------------------------------------------------
	public GameObject SpawnToScene(MapContainer _map) {
		
		map = _map;
		
		GenerateStats();
		GenerateRoot();
		GenerateNodes();
		SpawnTerrain();
		SpawnAllTerrainDoodats();
		SpawnSpawnPoints();
		
		return root;
	}
	
	// -----------------------------------------------------------------------------------
	// -----------------------------------------------------------------------------------
	// -----------------------------------------------------------------------------------
	
	private int IterateFleck (int x, int y, float radius) {
		int radiusUp = Mathf.CeilToInt(radius);
		int u = Mathf.Min(y + radiusUp, map.height - 1);
		int d = Mathf.Max(y - radiusUp, 0);
		int l = Mathf.Max(x - radiusUp, 0);
		int r = Mathf.Min(x + radiusUp, map.width - 1);
		int balance = 0;
		for (int i = l; i <= r; i++) {
			for (int j = d; j <= u; j++) {
				balance += data[j * map.width + i] == 1 ? 1 : -1;
			}
		}
		return balance > 0 ? 1 : 0;
	}

	private void BridgeAndBirthPoint (int groundCount) {

		int mainCount = 0;
		int currentIndex = 2;
		int[] tempData = new int[map.width * map.height];
		data.CopyTo(tempData, 0);
		List<List<Fleck>> zoneList = new List<List<Fleck>>();
		List<Vector2> pivotList = new List<Vector2>();
		
		GenerateStats();
		
		while (mainCount < groundCount) {
			// Start a new zone
			for (int i = 0; i < map.width; i++) {
				for (int j = 0; j < map.height; j++) {
					if (tempData[j * map.width + i] == 1) {
						List<Fleck> zone;
						Vector2 pivot;
						ZoneGrowRecursion(
							currentIndex, i, j,
							ref tempData, ref mainCount,
							out zone, out pivot
						);
						zoneList.Add(zone);
						pivotList.Add(pivot);
						currentIndex++;

						// Jump
						i = map.width;
						break;
					}
				}
			}
		}

		// Remove Small Zone
		int minBridgeNum = (map.bridge + 1) * 4;
		for (int i = 0; i < zoneList.Count; i++) {
			if (zoneList[i].Count < minBridgeNum) {
				zoneList.RemoveAt(i);
				pivotList.RemoveAt(i);
				i--;
			}
		}
	
		// --- Get Spawn Points Type A
		birthPointsA.Clear();
		if (maxBirthPointNumA > 0) {
			
			int birthCheckAdd = zoneList.Count <= maxBirthPointNumA ? 1 : zoneList.Count / maxBirthPointNumA;
			
			for (int i = 0; i < zoneList.Count; i += birthCheckAdd) {
				if (zoneList[i].Count <= 0) {
					continue;
				}
				int x = (int)pivotList[i].x;
				int y = (int)pivotList[i].y;
				int zoneIndex = tempData[zoneList[i][0].B * map.width + zoneList[i][0].A];
				Fleck target = ExpandToGet(tempData, x, y, zoneIndex, zoneList[i].Count);
				if (target.A > 0) {
					birthPointsA.Add(new Vector2(target.A, target.B));
					if (birthPointsA.Count >= maxBirthPointNumA) {
						break;
					}
				}
			}
		}
				
		// Return if no need to bridge
		if (map.bridge <= 0 || map.iteration <= 0) {
			return;
		}

		// Bridge Zones
		int len = zoneList.Count;
		if (len <= 1) {
			return;
		}
		List<Fleck> BridgedZone = new List<Fleck>(zoneList[0]);
		zoneList.RemoveAt(0);
		for (int count = 0; count < len - 1 && count < MAX_BRIDGE_COUNT; count++) {

			int indexB = -1;
			float finalMinDistance = float.MaxValue;
			Fleck pointA = new Fleck();
			Fleck pointB = new Fleck();
			for (int b = 0; b < zoneList.Count; b++) {
				// Get The Two Points
				List<Fleck> zoneB = zoneList[b];
				int zoneLenA = BridgedZone.Count;
				int zoneLenB = zoneB.Count;
				if (zoneLenA == 0 || zoneLenB == 0) {
					continue;
				}
				Fleck tempPointA = BridgedZone[0];
				Fleck tempPointB = zoneB[0];
				float minDis = Fleck.Distance(tempPointA, tempPointB);
				int addA = zoneLenA / 100 + 1;
				int addB = zoneLenB / 100 + 1;
				for (int i = 0; i < zoneLenA; i += addA) {
					for (int j = 0; j < zoneLenB; j += addB) {
						float dis = Fleck.Distance(BridgedZone[i], zoneB[j]);
						if (dis < minDis) {
							minDis = dis;
							tempPointA = BridgedZone[i];
							tempPointB = zoneB[j];
						}
					}
				}
				// Final
				if (minDis < finalMinDistance) {
					finalMinDistance = minDis;
					indexB = b;
					pointA = tempPointA;
					pointB = tempPointB;
				}
			}

			// Check
			if (indexB < 0) {
				break;
			}

			// Bridge Them
			float add = 0.5f / Mathf.Max(
				Mathf.Abs(pointA.A - pointB.A),
				Mathf.Abs(pointA.B - pointB.B)
			);
			Fleck prevF = new Fleck();
			for (float t = 0f; t < 1f + add * 2f; t += add) {

				Fleck f = Fleck.Lerp(pointA, pointB, t);

				// Concat Prev
				if (t != 0f) {
					if (f.A != prevF.A && f.B != prevF.B) {
						data[f.B * map.width + prevF.A] = 1;
					}
				} else {
					data[Mathf.Max(f.B - 1, 0) * map.width + f.A] = 1;
					data[Mathf.Min(f.B + 1, map.height - 1) * map.width + f.A] = 1;
					data[f.B * map.width + Mathf.Max(f.A - 1, 0)] = 1;
					data[f.B * map.width + Mathf.Min(f.A + 1, map.width - 1)] = 1;
				}
				prevF = f;

				// mapwidth
				int bmapwidth = map.bridge - 1;
				int d = Mathf.Max(f.B - bmapwidth, 0);
				int u = Mathf.Min(f.B + bmapwidth, map.height - 1);
				int l = Mathf.Max(f.A - bmapwidth, 0);
				int r = Mathf.Min(f.A + bmapwidth, map.width - 1);

				// Draw them
				for (int x = l; x <= r; x++) {
					for (int y = d; y <= u; y++) {
						data[y * map.width + x] = 1;
					}
				}

			}

			// Merge Them
			BridgedZone.AddRange(zoneList[indexB]);
			zoneList.RemoveAt(indexB);

		}


	}

	private void ZoneGrowRecursion (
		int currentIndex, int _x, int _y,
		ref int[] tempData, ref int mainCount,
		out List<Fleck> zone, out Vector2 pivot
	) {

		int pivotFleckCount = 0;
		pivot = new Vector2();
		zone = new List<Fleck>();
		Queue<Fleck> queue = new Queue<Fleck>();
		Fleck first = new Fleck(_x, _y);
		queue.Enqueue(first);

		while (queue.Count > 0) {

			Fleck f = queue.Dequeue();
			if (tempData[f.B * map.width + f.A] != 1) {
				continue;
			}
			int x = f.A;
			int y = f.B;
			tempData[y * map.width + x] = currentIndex;
			mainCount++;
			pivot += new Vector2(x, y);
			pivotFleckCount++;
			bool isEdge = CheckNeighbors(tempData, x, y, 0);
			f.IsEdge = isEdge;
			if (isEdge) {
				zone.Add(f);
			}

			// Check Neighbors
			bool u, d, l, r;
			CheckNeighbors(tempData, x, y, 1, out d, out u, out l, out r);
			if (d) {
				queue.Enqueue(new Fleck(x, y - 1));
			}
			if (u) {
				queue.Enqueue(new Fleck(x, y + 1));
			}
			if (l) {
				queue.Enqueue(new Fleck(x - 1, y));
			}
			if (r) {
				queue.Enqueue(new Fleck(x + 1, y));
			}

		}

		pivot /= pivotFleckCount;

	}



	private void CheckNeighbors (
		int[] tempData, int x, int y, int targetIndex,
		out bool d, out bool u, out bool l, out bool r
	) {
		d = y > 0 && tempData[(y - 1) * map.width + x] == targetIndex;
		u = y < map.height - 1 && tempData[(y + 1) * map.width + x] == targetIndex;
		l = x > 0 && tempData[y * map.width + x - 1] == targetIndex;
		r = x < map.width - 1 && tempData[y * map.width + x + 1] == targetIndex;
	}



	private bool CheckNeighbors (
		int[] tempData, int x, int y, int targetIndex
	) {
		return
			(y > 0 && tempData[(y - 1) * map.width + x] == targetIndex) ||
			(y < map.height - 1 && tempData[(y + 1) * map.width + x] == targetIndex) ||
			(x > 0 && tempData[y * map.width + x - 1] == targetIndex) ||
			(x < map.width - 1 && tempData[y * map.width + x + 1] == targetIndex);
	}


	private bool CheckNeighbors8 (
		int[] tempData, int x, int y, int targetIndex
	) {
		return
			(y > 0 && tempData[(y - 1) * map.width + x] == targetIndex) ||
			(y < map.height - 1 && tempData[(y + 1) * map.width + x] == targetIndex) ||
			(x > 0 && tempData[y * map.width + x - 1] == targetIndex) ||
			(x < map.width - 1 && tempData[y * map.width + x + 1] == targetIndex) ||

			(y > 0 && x > 0 && tempData[(y - 1) * map.width + x - 1] == targetIndex) ||
			(y < map.height - 1 && x < map.width - 1 && tempData[(y + 1) * map.width + x + 1] == targetIndex) ||
			(y < map.height - 1 && x > 0 && tempData[(y + 1) * map.width + x - 1] == targetIndex) ||
			(y > 0 && x < map.width - 1 && tempData[(y - 1) * map.width + x + 1] == targetIndex);
	}


	private Fleck ExpandToGet (
		int[] tempData, int _x, int _y, int targetIndex, int maxCount
	) {

		int checkedNum = 0;
		Dictionary<Fleck, byte> CheckedFleck = new Dictionary<Fleck, byte>();
		Queue<Fleck> queue = new Queue<Fleck>();
		queue.Enqueue(new Fleck(_x, _y));

		while (queue.Count > 0) {

			Fleck f = queue.Dequeue();
			int x = f.A;
			int y = f.B;

			if (CheckedFleck.ContainsKey(f)) {
				continue;
			} else {
				CheckedFleck.Add(f, 0);
				checkedNum++;
				if (checkedNum >= maxCount) {
					break;
				}
			}

			if (tempData[y * map.width + x] == targetIndex) {
				if (!CheckNeighbors8(tempData, x, y, 0)) {
					return f;
				}
			}

			if (y > 0) {
				queue.Enqueue(new Fleck(x, y - 1));
			}
			if (x > 0) {
				queue.Enqueue(new Fleck(x - 1, y));
			}
			if (y < map.height - 1) {
				queue.Enqueue(new Fleck(x, y + 1));
			}
			if (x < map.width - 1) {
				queue.Enqueue(new Fleck(x + 1, y));
			}
		}

		return new Fleck(-1, -1);
	}

}
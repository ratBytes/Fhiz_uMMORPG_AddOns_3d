﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using System.IO;

// ---------------------------------------------------------------------------------------
// ---------------------------------------------------------------------------------------
[CreateAssetMenu(menuName="MapGenerator/New MapContainer", order=999)]
public class MapContainer: ScriptableObject {
    
    [Header("[SETTINGS]")]
    [Range(0,999)]public float tileSize;
    [Range(0,999)]public float doodatSize;
    [Range(0,999)]public int width;
    [Range(0,999)]public int height;
    [Tooltip("Higher = less detailed land mass")]
    [Range(0,999)]public int iteration;
    [Range(0,999)]public int threshold;
    [Tooltip("Bridge width in tiles")]
    [Range(0,999)]public int bridge;
    [Range(0,999)]public int edge;
    [Range(0,999)]public int altitude;
    [Range(0,999)]public float bump;
    [Range(0,999)]public int nodeSize;
    
    [Header("[CUBES - per Biome]")]
    public TerrainCubes[] 	terrainCubes;
    
    [Header("[DOODATS - per Biome]")]
    public TerrainDoodats[]	bigDoodats;
    public TerrainDoodats[]	smallDoodats;
    public TerrainDoodats[]	tinyDoodats;
    
    [Header("[SPAWNPOINTS]")]
    public MapObject spawnPointA;
  	
	MapData m_CurrentMapData = null;
	float[] Seeds = null;
	string ExportPath = "Assets";
	
  	// -----------------------------------------------------------------------------------
  	// -----------------------------------------------------------------------------------
  	public void Generate() {
  	
  		CurrentMapData = new MapData();
		CurrentMapData.map = this;
		
		string resultPath = CombinePaths(ExportPath, CurrentMapData.name + ".prefab");
		CreateFolder(GetRelativeParentPath(resultPath));
			
		GenerateSeedAndMap();
  		GameObject g = CurrentMapData.SpawnToScene(this);
		PrefabUtility.SaveAsPrefabAsset(g, resultPath);
		DestroyImmediate(g, false);

		AssetDatabase.SaveAssets();
		AssetDatabase.Refresh(ImportAssetOptions.ForceUpdate);

		UnityEngine.Object obj = AssetDatabase.LoadAssetAtPath<UnityEngine.Object>(resultPath);
		if (obj) EditorGUIUtility.PingObject(obj);
		
  	}
  	
  	// -----------------------------------------------------------------------------------
   	
   	MapData CurrentMapData {
		get {
			if (m_CurrentMapData == null) {
				m_CurrentMapData = new MapData();
			}
			return m_CurrentMapData;
		}
		set {
			m_CurrentMapData = value;
		}
	}
	
   	void GenerateSeedAndMap (int width = -1, int height = -1) {
		width = width > 0 ? width : CurrentMapData.map.width;
		height = height > 0 ? height : CurrentMapData.map.height;
		Seeds = CurrentMapData.GetRandomSeeds();
		GenerateMap();
	}

	void GenerateMap (int width = -1, int height = -1) {
		width = width > 0 ? width : CurrentMapData.map.width;
		height = height > 0 ? height : CurrentMapData.map.height;
		if (Seeds == null) {
			GenerateSeedAndMap();
		} else {
			ClearProgressBar();
			CurrentMapData.Generate(Seeds, (progress) => {
				ProgressBar(
					"Exporting",
					string.Format("Generating map... {0}%", (progress * 100f).ToString("0")),
					progress
				);
			});
			ClearProgressBar();
		}
	}
   	// -----------------------------------------------------------------------------------
   	
   	public void ClearProgressBar () {
		EditorUtility.ClearProgressBar();
	}
	
	public void ProgressBar (string title, string msg, float value) {
		value = Mathf.Clamp01(value);
		EditorUtility.DisplayProgressBar(title, msg, value);
	}
		
   	public string GetFullPath (string path) {
		return new FileInfo(path).FullName;
	}

   	public string CombinePaths (params string[] paths) {
		string path = "";
		for (int i = 0; i < paths.Length; i++) {
			path = Path.Combine(path, FixPath(paths[i]));
		}
		return FixPath(path);
	}
		
   	public void CreateFolder (string _path) {
		_path = GetFullPath(_path);
		if (Directory.Exists(_path))
			return;
		string _parentPath = new FileInfo(_path).Directory.FullName;
		if (Directory.Exists(_parentPath)) {
			Directory.CreateDirectory(_path);
		} else {
			CreateFolder(_parentPath);
			Directory.CreateDirectory(_path);
		}
	}
	
	public string RelativePath (string path) {
		path = FixPath(path);
		if (path.StartsWith("Assets")) {
			return path;
		}
		if (path.StartsWith(FixPath(Application.dataPath))) {
			return "Assets" + path.Substring(FixPath(Application.dataPath).Length);
		} else {
			return "";
		}
	}
	
	public string FixPath (string _path) {
		_path = _path.Replace('\\', '/');
		_path = _path.Replace("//", "/");
		while (_path.Length > 0 && _path[0] == '/') {
			_path = _path.Remove(0, 1);
		}
		return _path;
	}
	
	public string GetRelativeParentPath (string path) {
		return RelativePath(new FileInfo(path).Directory.FullName);
	}
		
	// -----------------------------------------------------------------------------------
}

﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
namespace ACE
{
    public class rotate : MonoBehaviour
    {
        public Image wait;
        public float vel = 1;

        // Update is called once per frame
        void Update()
        {
           wait.transform.Rotate(Vector3.forward * vel * Time.deltaTime);
        }
    }
}
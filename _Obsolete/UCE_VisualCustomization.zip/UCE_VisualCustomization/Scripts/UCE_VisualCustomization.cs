// =======================================================================================
// Created and maintained by Fhiz
// Usable for both personal and commercial projects, but no sharing or re-sale
// * Discord Support Server.............: https://discord.gg/YkMbDHs
// * Public downloads website...........: https://www.indie-mmo.net
// * Pledge on Patreon for VIP AddOns...: https://www.patreon.com/IndieMMO
// =======================================================================================

using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using Mirror;

// =======================================================================================
// 
// =======================================================================================
[Serializable]
public partial struct UCE_VisualCustomization
{
    // hashcode used to reference the real ScriptableItem (can't link to data
    // directly because synclist only supports simple types). and syncing a
    // string's hashcode instead of the string takes WAY less bandwidth.
    public int hash;

   

    // constructors
    public UCE_VisualCustomization(UCE_VisualCustomizationTemplate data)
    {
        hash = data.name.GetStableHashCode();
        
    }

    // wrappers for easier access
    public UCE_VisualCustomizationTemplate data
    {
        get
        {
            // show a useful error message if the key can't be found
            // note: ScriptableItem.OnValidate 'is in resource folder' check
            //       causes Unity SendMessage warnings and false positives.
            //       this solution is a lot better.
            if (!UCE_VisualCustomizationTemplate.dict.ContainsKey(hash))
                throw new KeyNotFoundException("There is no UCE_VisualCustomization with hash=" + hash + ". Make sure that all UCE_VisualCustomization are in the Resources folder so they are loaded properly.");
            return UCE_VisualCustomizationTemplate.dict[hash];
        }
    }
    
    public string name { get { return data.name; } }
    
    public string categoryName { get { return data.categoryName; } }
    public GameObject playerPrefab { get { return data.playerPrefab; } }
    public GameObject customizationObject { get { return data.customizationObject; } }
    
    
   
}


public class SyncListUCE_VisualCustomization : SyncListSTRUCT<UCE_VisualCustomization> {}

// =======================================================================================

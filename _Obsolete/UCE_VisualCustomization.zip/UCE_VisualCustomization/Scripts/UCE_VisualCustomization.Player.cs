
using UnityEngine;
using UnityEngine.AI;
using Mirror;
using System;
using System.Linq;
using System.Collections.Generic;

// =======================================================================================
// PLAYER
// =======================================================================================
public partial class Player
{
	
	public SyncListUCE_VisualCustomization visualCustomization = new SyncListUCE_VisualCustomization();
	
	[Header("[ -=-=- UCE VISUAL CUSTOMIZATION INFO -=-=- ]")]
    public UCE_VisualCustomizationInfo[] visualCustomizationInfo = {
        new UCE_VisualCustomizationInfo{categoryName="SkinColor", 	location=null, defaultObject=null},
        new UCE_VisualCustomizationInfo{categoryName="HairStyle", 	location=null, defaultObject=null},
        new UCE_VisualCustomizationInfo{categoryName="EyeStyle", 	location=null, defaultObject=null},
        new UCE_VisualCustomizationInfo{categoryName="MouthStyle", 	location=null, defaultObject=null},
        
    };
    
    // -----------------------------------------------------------------------------------
    // RefreshLocation_UCE_VisualCustomization
    // -----------------------------------------------------------------------------------
    public void RefreshLocation_UCE_VisualCustomization(int index)
    {
    
    
    
    
    
    }
    
	// -----------------------------------------------------------------------------------
	
}

// =======================================================================================
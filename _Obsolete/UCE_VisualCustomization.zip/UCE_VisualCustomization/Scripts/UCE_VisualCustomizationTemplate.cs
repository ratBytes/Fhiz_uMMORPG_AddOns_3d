// =======================================================================================
// Created and maintained by Fhiz
// Usable for both personal and commercial projects, but no sharing or re-sale
// * Discord Support Server.............: https://discord.gg/YkMbDHs
// * Public downloads website...........: https://www.indie-mmo.net
// * Pledge on Patreon for VIP AddOns...: https://www.patreon.com/IndieMMO
// =======================================================================================

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

// =======================================================================================
// VISUAL CUSTOMIZATION TEMPLATE
// =======================================================================================
[CreateAssetMenu(fileName="UCE Visual Customization", menuName="UCE Templates/New UCE Visual Customization", order=999)]
public class UCE_VisualCustomizationTemplate : ScriptableObject {
	
	
	public string categoryName;
	public GameObject playerPrefab;
	
	public GameObject customizationObject;
	
	// -----------------------------------------------------------------------------------
     Dictionary<int, UCE_VisualCustomizationTemplate> cache;
    public  Dictionary<int, UCE_VisualCustomizationTemplate> dict
    {
        get
        {
            // load if not loaded yet
            return cache ?? (cache = Resources.LoadAll<UCE_VisualCustomizationTemplate>("").ToDictionary(
                x => x.name.GetStableHashCode(), x => x)
            );
        }
    }

	
}

// =======================================================================================
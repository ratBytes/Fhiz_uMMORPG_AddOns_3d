public partial struct Buff
{
    public float jumpPower { get { return data.jumpPower.Get(level); } }
}
public abstract partial class BuffSkill
{
    public LinearFloat jumpPower = new LinearFloat { baseValue = 0 };
}
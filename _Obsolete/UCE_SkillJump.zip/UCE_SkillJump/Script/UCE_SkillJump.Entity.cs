using Mirror;
using UnityEngine;

public abstract partial class Entity : NetworkBehaviour
{
    protected bool _isGrounded = true;

    // -----------------------------------------------------------------------------------
    //
    // -----------------------------------------------------------------------------------
    [DevExtMethods("Update")]
    private void Update_UCE_SkillJump()
    {
        /*
   		float jumpPower 	= buffs.Sum(buff => buff.jumpPower);

     	if (_isGrounded && jumpPower > 0 || flyHeight > 0) {
     		//agent.ResetMovement();

     		//agent.updatePosition = false;
     		//GetComponent<Rigidbody>().isKinematic = false;
     		//GetComponent<Rigidbody>().useGravity = true;
     		//GetComponent<Rigidbody>().AddForce(new Vector3(0, jumpPower, 0), ForceMode.VelocityChange);

     		_isGrounded = false;
     	}*/
    }

    // -----------------------------------------------------------------------------------
    //
    // -----------------------------------------------------------------------------------
    [DevExtMethods("OnTriggerEnter")]
    protected void OnTriggerEnter_UCE_SkillJump(Collider other)
    {
        /*
		if (_isGrounded) return;

		if (other.gameObject.tag == "Ground" && !_isGrounded) {
	 		_isGrounded = true;
	 		agent.updatePosition = true;
     		//GetComponent<Rigidbody>().isKinematic = true;
     		//GetComponent<Rigidbody>().useGravity = false;
     		//GetComponent<NavMeshAgent>().baseOffset = 0;
		}
		*/
    }

    // -----------------------------------------------------------------------------------
}
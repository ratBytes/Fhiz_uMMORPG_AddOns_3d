// =======================================================================================
// Created and maintained by Fhiz
// Usable for both personal and commercial projects, but no sharing or re-sale
// * Discord Support Server.............: https://discord.gg/YkMbDHs
// * Public downloads website...........: https://www.indie-mmo.net
// * Pledge on Patreon for VIP AddOns...: https://www.patreon.com/IndieMMO
// =======================================================================================
using UnityEngine;
using Mirror;
using System.Linq;
using System.Collections.Generic;

// =======================================================================================
// BALLISTIC SKILL EFFECT
// =======================================================================================
[RequireComponent(typeof(Rigidbody))]
public class UCE_BallisticSkillEffect : SkillEffect {

	[Header("-=-=-=- Settings -=-=-=-")]
	public float speed = 1;
	[Tooltip("[Optional] Select a tag that act as wall and stops the projectile")]
	public string wallTag;
	
	[Header("-=-=-=- Visual Effects -=-=-=-")]
	[Range(10f, 80f)] public float angle 	= 15f; 						// should be 15-45 for best results
	public int destroyDelay 				= 1;
    public GameObject impactObject;
    
    [Header("-=-=-=- Create GameObject on Target -=-=-=-")]
	public GameObject[] createOnTarget;
	public LevelBasedFloat createChance; 

    [HideInInspector] public int damage = 1; 							// set by skill
	[HideInInspector] public float stunChance; 							// set by skill
    [HideInInspector] public float stunTime; 							// set by skill
	[HideInInspector] public int skillLevel; 							// set by skill

    [HideInInspector] public BuffSkill applyBuff; 						// set by skill
	[HideInInspector] public int buffLevel; 							// set by skill
	[HideInInspector] public float buffChance; 							// set by skill
    
	[HideInInspector] public OneTimeTargetSkillEffect impactEffect; 	// set by skill
	[HideInInspector] public float castRadius; 							// set by skill
    [HideInInspector] public float triggerAggroChance; 					// set by skill
    [HideInInspector] public bool SpawnEffectOnMainTargetOnly; 			// set by skill
    
	[HideInInspector] public bool NotAffectSelf; 						// set by skill
	[HideInInspector] public bool NotAffectOwnParty; 					// set by skill
	[HideInInspector] public bool NotAffectOwnGuild; 					// set by skill
	[HideInInspector] public bool NotAffectOwnRealm; 					// set by skill
	
	[HideInInspector] public int removeRandomBuff; 					// set by skill
	[HideInInspector] public float removeChance; 					// set by skill
	  
    protected bool impact = false;
    
    // -----------------------------------------------------------------------------------
    // Start
    // -----------------------------------------------------------------------------------
    void Start() {
    	Vector3 goal = target.collider.bounds.center; 
    	GetComponent<Rigidbody>().velocity = calcBallisticVelocityVector(caster.transform, goal, angle);
    	FixedUpdate();
    }
    
    // -----------------------------------------------------------------------------------
    // OnStartClient
    // -----------------------------------------------------------------------------------
     public override void OnStartClient() {
        if (target != null && caster != null) {
            transform.position = caster.effectMount.position;
            transform.LookAt(target.collider.bounds.center);
        }
    }

    // -----------------------------------------------------------------------------------
    // FixedUpdate
    // -----------------------------------------------------------------------------------
    void FixedUpdate() {
        if (target != null && caster != null) {
            Vector3 goal = target.collider.bounds.center;
            transform.LookAt(goal);
        } else if (isServer && caster == null) {
        	NetworkServer.Destroy(gameObject);
    	}
    }
    
    // -----------------------------------------------------------------------------------
	// SpawnEffect
	// -----------------------------------------------------------------------------------
    public void SpawnEffect(Entity caster, Entity spawnTarget)
    {
        if (impactEffect != null)
        {
            GameObject go = Instantiate(impactEffect.gameObject, spawnTarget.transform.position, Quaternion.identity);
            go.GetComponent<OneTimeTargetSkillEffect>().caster = caster;
            go.GetComponent<OneTimeTargetSkillEffect>().target = spawnTarget;
            NetworkServer.Spawn(go);
        }
    }
    
    // -----------------------------------------------------------------------------------
    // onCollissionEnter
    // -----------------------------------------------------------------------------------
    [ServerCallback]
    void onCollissionEnter(Collision collision) {
    
    	if (!isServer || impact) return;
    	
    	Entity candidate = null;
    	
    	foreach (ContactPoint contact in collision.contacts)
        {
            
            candidate = contact.otherCollider.GetComponentInParent<Entity>();
			
			if (candidate != null && caster.CanAttack(candidate) && candidate.health > 0) {
				
				Apply();
				
				if (destroyDelay != 0) {
					Invoke("OnDestroyDelayed", destroyDelay);
					impact = true;
				} else {
					OnDestroyDelayed();
				}
				
			}
            
            
        }
    
    }
    
    // -----------------------------------------------------------------------------------
	// Apply
	// -----------------------------------------------------------------------------------
    public void Apply()
    {
    	
    	List<Entity> targets = new List<Entity>();
    	
    	// ------ spawn visual effect if any
    	if (SpawnEffectOnMainTargetOnly)
    		SpawnEffect(caster, caster.target);
    	
    	// ------ get all valid targets
    	if (caster is Player)
    		targets = ((Player)caster).UCE_GetCorrectedTargetsInSphere(caster.target.transform, castRadius, false, NotAffectSelf, NotAffectOwnParty, NotAffectOwnGuild, NotAffectOwnRealm, true);
    	else
    		targets = caster.UCE_GetCorrectedTargetsInSphere(caster.target.transform, castRadius, false, NotAffectSelf, NotAffectOwnParty, NotAffectOwnGuild, NotAffectOwnRealm, true);
    	
    	// ----- apply effects to targets
    	foreach (Entity target in targets)
    	{
    		
    		// ------ deal damage directly with base damage + skill damage
       		caster.DealDamageAt(target, caster.damage + damage, stunChance, stunTime);
       		
       		// ------ remove random buff
       		if (removeRandomBuff > 0 && caster.target.buffs.Count > 0) {
       			caster.target.UCE_CleanupStatusBuffs(removeChance, removeRandomBuff);
       		}
       				
       		// ------ apply buff
       		target.UCE_ApplyBuff(applyBuff, buffLevel, buffChance);
       		
       		// ------ spawn visual effect if any
			if (!SpawnEffectOnMainTargetOnly)
				SpawnEffect(caster, target);
    	
    		if (UnityEngine.Random.value <= triggerAggroChance)
				target.target = caster;
				
    	}
    	
    	// ------ create object at impact loaction
       	if (createOnTarget.Length >= skillLevel-1 && createOnTarget[skillLevel-1] != null && UnityEngine.Random.value <= createChance.Get(skillLevel)) {
       		GameObject go = Instantiate(createOnTarget[skillLevel-1], caster.target.transform.position, caster.target.transform.rotation);
       		NetworkServer.Spawn(go);
       	}
    	
        targets.Clear();
        
    }
    
    // -----------------------------------------------------------------------------------
    // OnDestroyDelayed
    // -----------------------------------------------------------------------------------
    protected void OnDestroyDelayed() {
    	CancelInvoke("OnDestroyDelayed");
    	NetworkServer.Destroy(gameObject);
    }
    
    // -----------------------------------------------------------------------------------
    // calcBallisticVelocityVector
    // -----------------------------------------------------------------------------------
    protected Vector3 calcBallisticVelocityVector(Transform source, Vector3 target, float angle) {
         Vector3 direction = target - source.position;
         float h = direction.y;                                          // get height difference
         direction.y = 0;                                                // remove height
         float distance = direction.magnitude;                           // get horizontal distance
         float a = angle * Mathf.Deg2Rad;                                // Convert angle to radians
         direction.y = distance * Mathf.Tan(a);                          // Set direction to elevation angle
         distance += h/Mathf.Tan(a);                                     // Correction for small height differences
         float velocity = Mathf.Sqrt(distance * Physics.gravity.magnitude / Mathf.Sin(2*a));
         return velocity * direction.normalized;
	}
	
	// -----------------------------------------------------------------------------------
	
}



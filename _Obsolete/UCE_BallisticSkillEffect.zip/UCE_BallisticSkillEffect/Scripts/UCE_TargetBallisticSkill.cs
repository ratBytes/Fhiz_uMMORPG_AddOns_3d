// =======================================================================================
// Created and maintained by Fhiz
// Usable for both personal and commercial projects, but no sharing or re-sale
// * Discord Support Server.............: https://discord.gg/YkMbDHs
// * Public downloads website...........: https://www.indie-mmo.net
// * Pledge on Patreon for VIP AddOns...: https://www.patreon.com/IndieMMO
// =======================================================================================
using System.Text;
using UnityEngine;
using Mirror;

// =======================================================================================
// TARGET BALLISTIC SKILL
// =======================================================================================
[CreateAssetMenu(menuName="uMMORPG Skill/UCE Target Ballistic Skill", order=999)]
public class UCE_TargetBallisticSkill : ScriptableSkill {
	
	[Header("-=-=-=- Ballistic Projectile -=-=-=-")]
    public LevelBasedInt damage = new LevelBasedInt{baseValue=1};
    public LevelBasedFloat stunChance; 									// range [0,1]
    public LevelBasedFloat stunTime; 									/// in seconds
    [Tooltip("Assign one projectile per skill level")]
    public UCE_BallisticSkillEffect[] projectiles;
 
	[Header("-=-=-=- Visual Effects -=-=-=-")]
	public GameObject muzzleEffect;
	
    [Header("-=-=-=- Buff Target -=-=-=-")]
    public BuffSkill applyBuff;
	public int buffLevel;
	[Range(0,1)]public float buffChance;
	
	[Header("-=-=-=- Debuff Target -=-=-=-")]
	[Tooltip("Remove up to x Buffs (positive status effects) from the target")]
	public LevelBasedInt removeRandomBuff;
	public LevelBasedFloat removeChance; 

   	[Header("-=-=-=- Target AOE Effect -=-=-=-")]
	public OneTimeTargetSkillEffect impactEffect;
	public LevelBasedFloat castRadius;
    public LevelBasedFloat triggerAggroChance;
    public bool SpawnEffectOnMainTargetOnly;
    
	[Header("-=-=-=- Targeting -=-=-=-")]
	[Tooltip("[Optional] Does affect the caster")]
	public bool NotAffectSelf;
	[Tooltip("[Optional] Does affect members of the own party")]
	public bool NotAffectOwnParty;
	[Tooltip("[Optional] Does affect members of the own guild")]
	public bool NotAffectOwnGuild;
	[Tooltip("[Optional] Does affect members of the own realm (requires UCE PVP ZONE AddOn")]
	public bool NotAffectOwnRealm;
   	
   	// -----------------------------------------------------------------------------------
	// SpawnEffect
	// -----------------------------------------------------------------------------------
    public void SpawnEffect(Entity caster, Entity spawnTarget)
    {
        if (impactEffect != null)
        {
            GameObject go = Instantiate(impactEffect.gameObject, spawnTarget.transform.position, Quaternion.identity);
            go.GetComponent<OneTimeTargetSkillEffect>().caster = caster;
            go.GetComponent<OneTimeTargetSkillEffect>().target = spawnTarget;
            NetworkServer.Spawn(go);
        }
    }
    
	// -----------------------------------------------------------------------------------
	// CheckTarget
	// -----------------------------------------------------------------------------------
    public override bool CheckTarget(Entity caster) {
        return caster.target != null && caster.target != caster && caster.CanAttack(caster.target);
    }
    
	// -----------------------------------------------------------------------------------
	// CheckDistance
	// -----------------------------------------------------------------------------------
    public override bool CheckDistance(Entity caster, int skillLevel, out Vector3 destination) {
        if (caster.target != null) {
            destination = caster.target.collider.ClosestPointOnBounds(caster.transform.position);
            return Utils.ClosestDistance(caster.collider, caster.target.collider) <= castRange.Get(skillLevel);
        }
        destination = caster.transform.position;
        return false;
    }
    
	// -----------------------------------------------------------------------------------
	// Apply
	// -----------------------------------------------------------------------------------
    public override void Apply(Entity caster, int skillLevel) {
        
        if (projectiles.Length == 0) {
        	Debug.LogWarning("You forgot to assign BallisticSkillEffect to Target Ballistic Skill!");
        	return;
        }
        
        if (muzzleEffect != null) {
        	GameObject go = Instantiate(muzzleEffect.gameObject, caster.effectMount.position, caster.effectMount.rotation);
        	NetworkServer.Spawn(go);
        }
        
        UCE_BallisticSkillEffect projectile = projectiles[0];
        
        if (projectiles.Length >= skillLevel)
        	projectile = projectiles[skillLevel-1];
        
        if (projectile != null) {
        
            GameObject go = Instantiate(projectile.gameObject, caster.effectMount.position, caster.effectMount.rotation);
            UCE_BallisticSkillEffect effect = go.GetComponent<UCE_BallisticSkillEffect>();
            
            effect.target 						= caster.target;
            effect.caster 						= caster;
            effect.damage 						= damage.Get(skillLevel);
            effect.applyBuff 					= applyBuff;
            effect.buffLevel 					= buffLevel;
            effect.buffChance 					= buffChance;
            effect.stunChance 					= stunChance.Get(skillLevel);
            effect.stunTime 					= stunTime.Get(skillLevel);
        	effect.skillLevel 					= skillLevel;
        	effect.impactEffect					= impactEffect;
        	effect.castRadius					= castRadius.Get(skillLevel);
        	effect.triggerAggroChance			= triggerAggroChance.Get(skillLevel);
        	effect.SpawnEffectOnMainTargetOnly	= SpawnEffectOnMainTargetOnly;
        	effect.NotAffectSelf				= NotAffectSelf;
        	effect.NotAffectOwnParty			= NotAffectOwnParty;
        	effect.NotAffectOwnGuild			= NotAffectOwnGuild;
        	effect.NotAffectOwnRealm			= NotAffectOwnRealm;
        	effect.removeRandomBuff				= removeRandomBuff.Get(skillLevel);
        	effect.removeChance					= removeChance.Get(skillLevel);
        	
            NetworkServer.Spawn(go);
        }
        else Debug.LogWarning(name + ": missing projectile");
    }
    
	// -----------------------------------------------------------------------------------
	// ToolTip
	// -----------------------------------------------------------------------------------
    public override string ToolTip(int skillLevel, bool showRequirements = false) {
        StringBuilder tip = new StringBuilder(base.ToolTip(skillLevel, showRequirements));
        tip.Replace("{DAMAGE}", damage.Get(skillLevel).ToString());
        return tip.ToString();
    }
    
    // -----------------------------------------------------------------------------------
    
}

// =======================================================================================

// =======================================================================================
// Created and maintained by Fhiz
// Usable for both personal and commercial projects, but no sharing or re-sale
// * Discord Support Server.............: https://discord.gg/YkMbDHs
// * Public downloads website...........: https://www.indie-mmo.net
// * Pledge on Patreon for VIP AddOns...: https://www.patreon.com/IndieMMO
// =======================================================================================
using UnityEngine;
using UnityEngine.Events;
using Mirror;

// =======================================================================================
// PROJECTILE SKILL EFFECT
// =======================================================================================
public class UCE_ProjectileSkillEffect : SkillEffect {

    public float speed = 35;
    [HideInInspector] public int damage = 1; // set by skill
    [HideInInspector] public float stunChance; // set by skill
    [HideInInspector] public float stunTime; // set by skill
	[HideInInspector] public int skillLevel; // set by skill
	
	[Header("-=-=-=- Buff Target -=-=-=-")]
	public BuffSkill applyBuff;
	public LevelBasedInt buffLevel;
	public LevelBasedFloat buffChance;
	
	[Header("-=-=-=- Debuff Target -=-=-=-")]
	[Tooltip("Remove up to x Buffs (positive status effects) from the target")]
	public LevelBasedInt removeRandomBuff;
	public LevelBasedFloat removeChance; 
	
	[Header("-=-=-=- Create GameObject -=-=-=-")]
	public GameObject[] createOnTarget;
	public LevelBasedFloat createChance; 
	
    // effects like a trail or particles need to have their initial positions
    // corrected too. simply connect their .Clear() functions to the event.
    public UnityEvent onSetInitialPosition;

    public override void OnStartClient()
    {
        SetInitialPosition();
    }

    void SetInitialPosition()
    {
        // the projectile should always start at the effectMount position.
        // -> server doesn't run animations, so it will never spawn it exactly
        //    where the effectMount is on the client by the time the packet
        //    reaches the client.
        // -> the best solution is to correct it here once
        if (target != null && caster != null)
        {
            transform.position = caster.effectMount.position;
            transform.LookAt(target.collider.bounds.center);
            onSetInitialPosition.Invoke();
        }
    }

    // fixedupdate on client and server to simulate the same effect without
    // using a NetworkTransform
    void FixedUpdate()
    {
        // target and caster still around?
        // note: we keep flying towards it even if it died already, because
        //       it looks weird if fireballs would be canceled inbetween.
        if (target != null && caster != null)
        {
            // move closer and look at the target
            Vector3 goal = target.collider.bounds.center;
            transform.position = Vector3.MoveTowards(transform.position, goal, speed * Time.fixedDeltaTime);
            transform.LookAt(goal);

            // server: reached it? apply skill and destroy self
            if (isServer && transform.position == goal)
            {
                if (target.health > 0)
                {
                    
                    // find the skill that we casted this effect with
                    caster.DealDamageAt(target, caster.damage + damage, stunChance, stunTime);
                    
                    // ------ remove random buff
       				if (removeRandomBuff.Get(skillLevel) > 0 && caster.target.buffs.Count > 0) {
       					caster.target.UCE_CleanupStatusBuffs(removeChance.Get(skillLevel), removeRandomBuff.Get(skillLevel));
       				}
                    
                    // ------ apply a buff
        			caster.target.UCE_ApplyBuff(applyBuff, buffLevel.Get(skillLevel), buffChance.Get(skillLevel));
       				       				
                }
                
                // create object
       			if (createOnTarget.Length > 0 && createOnTarget.Length >= skillLevel-1 && createOnTarget[skillLevel-1] != null && UnityEngine.Random.value <= createChance.Get(skillLevel)) {
       				GameObject go = Instantiate(createOnTarget[skillLevel-1], caster.target.transform.position, caster.target.transform.rotation);
       				NetworkServer.Spawn(go);
       			}
                
                NetworkServer.Destroy(gameObject);
            }
        }
        else if (isServer) NetworkServer.Destroy(gameObject);
    }
}

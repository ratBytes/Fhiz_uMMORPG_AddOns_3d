﻿using UnityEngine;
using UnityEngine.UI;

public class UCE_ConfirmDelete : MonoBehaviour
{
    #region Variables

    [Header("Confirm Delete")]
    [SerializeField] private Button btnPopupClose = null;
    [SerializeField] private Button btnPopupConfirm = null;
    [SerializeField] private GameObject gboPopupPanel = null;
    [SerializeField] private Text txtPopupMessage = null;
    [SerializeField] private string message = "Do you wish to delete this character?";

    private NetworkManagerMMO manager; // singleton is null until update
    private Button btnSelectDelete;

    #endregion Variables

    #region Functions

    // Set our manager and delete button, create our listener for the character select delete button to be clicked.
    private void Start()
    {
        manager = GetComponent<UICharacterSelection>().manager;
        btnSelectDelete = GetComponent<UICharacterSelection>().deleteButton;
        btnSelectDelete.onClick.AddListener(ConfirmationPopup);
    }

    // Set our delete button to only show when a character is selected.
    private void Update()
    {
        btnSelectDelete.gameObject.SetActive(manager.selection != -1);
    }

    // Assign our message, assign our confirm delete button, then show our popup.
    private void ConfirmationPopup()
    {
        txtPopupMessage.text = message;
        btnPopupConfirm.GetComponentInChildren<Text>().text = "Delete";
        btnPopupConfirm.onClick.AddListener(ConfirmDelete);
        btnPopupClose.onClick.AddListener(ConfirmCancel);
        gboPopupPanel.SetActive(true);
    }

    // Delete the character now that confirmation has been made.
    private void ConfirmDelete()
    {
        CharacterDeleteMsg message = new CharacterDeleteMsg();
        message.value = manager.selection;
        manager.client.Send(message);

        ConfirmCancel();
    }

    // Cancel the character deletion.
    private void ConfirmCancel()
    {
        btnPopupConfirm.onClick.RemoveListener(ConfirmDelete);
        gboPopupPanel.SetActive(false);
        txtPopupMessage.text = "";
        btnPopupConfirm.GetComponentInChildren<Text>().text = "Got It!";
        btnPopupClose.onClick.RemoveListener(ConfirmCancel);
    }

    #endregion Functions
}
// =======================================================================================
// Created and maintained by Fhiz
// Usable for both personal and commercial projects, but no sharing or re-sale
// * Discord Support Server.............: https://discord.gg/YkMbDHs
// * Public downloads website...........: https://www.indie-mmo.net
// * Pledge on Patreon for VIP AddOns...: https://www.patreon.com/IndieMMO
// =======================================================================================
using System.Text;
using UnityEngine;
using Mirror;

// =======================================================================================
// TARGET DAMAGE IMPACT SKILL
// =======================================================================================
[CreateAssetMenu(menuName="uMMORPG Skill/UCE Target Damage Impact Skill", order=999)]
public class TargetDamageImpactSkill : TargetDamageSkill {

	public GameObject[] impactObjects;

    [Header("-=-=-=- Buff on Target -=-=-=-")]
    public BuffSkill applyBuff;
	public int buffLevel;
	[Range(0,1)]public float buffChance;
	
	// -----------------------------------------------------------------------------------
	// GetIndex
	// -----------------------------------------------------------------------------------
    protected int GetIndex() {
    	
    	int index = 0;
    	
    	if (impactObjects != null && impactObjects.Length > 1) {
        
			float[] f = new float[impactObjects.Length];

			for ( int i = 0; i < impactObjects.Length; i++ )
				f[i] = impactObjects[i].GetComponent<UCE_WeightedObject>().chance;

			index = UCE_Tools.WeightedRandomIndex(f);

		}
		
		return index;
		
    }
    
	// -----------------------------------------------------------------------------------
	// CheckTarget
	// -----------------------------------------------------------------------------------
    public override bool CheckTarget(Entity caster) {
        return caster.target != null && caster.CanAttack(caster.target);
    }
    
	// -----------------------------------------------------------------------------------
	// CheckDistance
	// -----------------------------------------------------------------------------------
    public override bool CheckDistance(Entity caster, int skillLevel, out Vector3 destination) {
        if (caster.target != null) {
            destination = caster.target.collider.ClosestPointOnBounds(caster.transform.position);
            return Utils.ClosestDistance(caster.collider, caster.target.collider) <= castRange.Get(skillLevel);
        }
        destination = caster.transform.position;
        return false;
    }
    
	// -----------------------------------------------------------------------------------
	// Apply
	// -----------------------------------------------------------------------------------
    public override void Apply(Entity caster, int skillLevel) {
        
        if (caster.target.health > 0)
        {
        	caster.target.UCE_ApplyBuff(applyBuff, buffLevel, buffChance);
        	caster.DealDamageAt(caster.target, caster.damage + damage.Get(skillLevel));
        }
        
        GameObject impactObject = impactObjects[GetIndex()];
        
        if (impactObject != null) {
            GameObject go = Instantiate(impactObject.gameObject, caster.target.transform.position, caster.target.transform.rotation);
            NetworkServer.Spawn(go);
        }
        else Debug.LogWarning(name + ": missing impact gameobject");
        		
    }
    
    // -----------------------------------------------------------------------------------
    
}

// =======================================================================================
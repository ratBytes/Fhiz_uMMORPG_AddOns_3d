﻿////////////////////////////////////////////////////////////////////////////////
// Example Addon
//    Author: ...
//
//    Description: ...
//
//    Required Core modifications: ...
//
//    Usage: ...
//
using System.Text;
using System.Collections.Generic;
using UnityEngine;
using Mirror;
using Mono.Data.Sqlite;
using System;
using UnityEngine.UI;
using TMPro;

public partial class Player
{
    //[SyncVar] int example;

    [Command]
    public void CmdgiveItemExperience(int index, int amount) {

        ItemSlot temp = equipment[index];
        temp.experience += amount;
        if(temp.experience > temp.computeLevel()) {
            temp.experience -= (int) temp.computeLevel();
            if(temp.level < temp.item.data.MaxLevel)
                temp.level++;
        }

        equipment[index] = temp;
    }

    [Server] void DealDamageAt_ItemLevelingAddon(Entity entity, int amount) {
        
        if(equipment[0].amount <= 0) return;

            CmdgiveItemExperience(0, amount/2);
    }
}

public partial class Entity
{
    [Server] void DealDamageAt_ItemLevelingAddon(Entity entity, int amount) {
        if(entity is Player) {
            Player player = (Player) entity;
            
        int amountOfEquippedItems = 0;
            for(int i = 0; i < player.equipment.Count; i++) {
                if(i != 0 && i != 4) {
                if (player.equipment[i].amount > 0) amountOfEquippedItems++;
                }
            }
            for(int i = 0; i < player.equipment.Count; i++) {
                if(i != 0 && i != 4) {
                    if (player.equipment[i].amount > 0) player.CmdgiveItemExperience(i, amount/amountOfEquippedItems);
                }
            }
        }
    }
}

public partial struct ItemSlot {
    public float computeLevel() {

        float amount = 1;
        amount = level*level*12;
        return amount;
    }
}

public partial class ScriptableItem {
    public int MaxLevel = 99;
    public float levelMultiplier = 0.1f;
}

public partial class UIInventorySlot { 
    public Text levelText;
    public TextMeshProUGUI levelTMP;
}

public partial struct Quest {
    public List<ScriptableItemAndAmount> rewardItems => data.rewardItems;
}


public partial class Database
{
    void Connect_ItemLevelingAddon()
    {
        // it's usually best to create an extra table for your addon. example:
        //ExecuteNonQuery(@"CREATE TABLE IF NOT EXISTS example (
        //                  name TEXT NOT NULL PRIMARY KEY)");

        ExecuteNonQuery(@"CREATE TABLE IF NOT EXISTS character_inventoryLevels (
                            character TEXT NOT NULL,
                            slot INTEGER NOT NULL,
                            level INTEGER NOT NULL,
                            experience INTEGER NOT NULL,
                            PRIMARY KEY(character, slot))");

        // [PRIMARY KEY is important for performance: O(log n) instead of O(n)]
        ExecuteNonQuery(@"CREATE TABLE IF NOT EXISTS character_equipmentLevels (
                            character TEXT NOT NULL,
                            slot INTEGER NOT NULL,
                            level INTEGER NOT NULL,
                            experience INTEGER NOT NULL,
                            PRIMARY KEY(character, slot))");
    }
    void CharacterLoad_ItemLevelingAddon(Player player) {
        LoadInventoryLevels(player);
        LoadEquipmentLevels(player);
    }
    void CharacterSave_ItemLevelingAddon(Player player) {
        SaveInventoryLevels(player);
        SaveEquipmentLevels(player);
    }

    void LoadInventoryLevels(Player player)
    {
        // fill all slots first
        for (int i = 0; i < player.inventorySize; ++i)
            player.inventory.Add(new ItemSlot());

        // then load valid items and put into their slots
        // (one big query is A LOT faster than querying each slot separately)
        List< List<object> > table = ExecuteReader("SELECT slot, level, experience FROM character_inventoryLevels WHERE character=@character", new SqliteParameter("@character", player.name));
        foreach (List<object> row in table)
        {
            int slot = Convert.ToInt32((long)row[0]);
            if (slot < player.inventorySize)
            {
                ItemSlot temp = player.inventory[slot];
                if (ScriptableItem.dict.TryGetValue(temp.item.name.GetStableHashCode(), out ScriptableItem itemData))
                {
                    Item item = temp.item;
                    int amount = temp.amount;
                    int level = Convert.ToInt32((long)row[1]);
                    int experience = Convert.ToInt32((long)row[2]);
                    player.inventory[slot] = new ItemSlot(item, amount, level, experience);
                }
                else Debug.LogWarning("LoadInventory: skipped item " + temp.item.name + " for " + player.name + " because it doesn't exist anymore. If it wasn't removed intentionally then make sure it's in the Resources folder.");
            }
            else Debug.LogWarning("LoadInventory: skipped slot " + slot + " for " + player.name + " because it's bigger than size " + player.inventorySize);
        }
    }

    void LoadEquipmentLevels(Player player)
    {
        // fill all slots first
        //for (int i = 0; i < player.equipmentInfo.Length; ++i)
        //    player.equipment.Add(new ItemSlot());

        // then load valid equipment and put into their slots
        // (one big query is A LOT faster than querying each slot separately)
        List< List<object> > table = ExecuteReader("SELECT slot, level, experience FROM character_equipmentLevels WHERE character=@character", new SqliteParameter("@character", player.name));
        foreach (List<object> row in table)
        {
            int slot = Convert.ToInt32((long)row[0]);
            if (slot < player.equipmentInfo.Length)
            {
                ItemSlot temp = player.equipment[slot];
                if (ScriptableItem.dict.TryGetValue(player.equipment[slot].item.name.GetStableHashCode(), out ScriptableItem itemData))
                {
                    Item item = temp.item;
                    int amount = temp.amount;
                    int level = Convert.ToInt32((long)row[1]);
                    int experience = Convert.ToInt32((long)row[2]);


                    player.equipment[slot] = new ItemSlot(item, amount, level, experience);
                }
                else Debug.LogWarning("LoadEquipment: skipped item " + temp.item.name + " for " + player.name + " because it doesn't exist anymore. If it wasn't removed intentionally then make sure it's in the Resources folder.");
            }
            else Debug.LogWarning("LoadEquipment: skipped slot " + slot + " for " + player.name + " because it's bigger than size " + player.equipmentInfo.Length);
        }
    }

    //TODO DOWN
    
    void SaveInventoryLevels(Player player)
    {
        // inventory: remove old entries first, then add all new ones
        // (we could use UPDATE where slot=... but deleting everything makes
        //  sure that there are never any ghosts)
        ExecuteNonQuery("DELETE FROM character_inventoryLevels WHERE character=@character", new SqliteParameter("@character", player.name));
        for (int i = 0; i < player.inventory.Count; ++i)
        {
            ItemSlot slot = player.inventory[i];
            if (slot.amount > 0) // only relevant items to save queries/storage/time
                ExecuteNonQuery("INSERT INTO character_inventoryLevels VALUES (@character, @slot, @level, @experience)",
                                new SqliteParameter("@character", player.name),
                                new SqliteParameter("@slot", i),
                                new SqliteParameter("@level", slot.level),
                                new SqliteParameter("@experience", slot.experience));
        }
    }

    void SaveEquipmentLevels(Player player)
    {
        // equipment: remove old entries first, then add all new ones
        // (we could use UPDATE where slot=... but deleting everything makes
        //  sure that there are never any ghosts)
        ExecuteNonQuery("DELETE FROM character_equipmentLevels WHERE character=@character", new SqliteParameter("@character", player.name));
        for (int i = 0; i < player.equipment.Count; ++i)
        {
            ItemSlot slot = player.equipment[i];
            if (slot.amount > 0) // only relevant equip to save queries/storage/time
                ExecuteNonQuery("INSERT INTO character_equipmentLevels VALUES (@character, @slot, @level, @experience)",
                                new SqliteParameter("@character", player.name),
                                new SqliteParameter("@slot", i),
                                new SqliteParameter("@level", slot.level),
                                new SqliteParameter("@experience", slot.experience));
        }
    }
}

﻿////////////////////////////////////////////////////////////////////////////////
// Example Addon
//    Author: ...
//
//    Description: ...
//
//    Required Core modifications: ...
//
//    Usage: ...
//
using System.Text;
using System.Collections.Generic;
using UnityEngine;
using Mirror;
using Mono.Data.Sqlite;
using System;
using UnityEngine.UI;
using TMPro;

public partial class Database
{
    void Connect_ItemLevelingGuildWarehouseAddon()
    {
        // it's usually best to create an extra table for your addon. example:
        //ExecuteNonQuery(@"CREATE TABLE IF NOT EXISTS example (
        //                  name TEXT NOT NULL PRIMARY KEY)");
        ExecuteNonQuery(@"CREATE TABLE IF NOT EXISTS 'UCE_guild_warehouse_levels' (
                           'guild' TEXT NOT NULL,
                           'slot' INTEGER NOT NULL,
                           'level' INTEGER NOT NULL,
                           'experience' INTEGER NOT NULL)");
    }
    void CharacterLoad_ItemLevelingGuildWarehouseAddon(Player player) {
        LoadGuildWarehouseLevels(player);
    }
    void CharacterSave_ItemLevelingGuildWarehouseAddon(Player player) {
        SaveGuildWarehouseLevels(player);
    }

    public void LoadGuildWarehouseLevels(Player player)
    {
		Debug.Log("Loaded Guild DB");
        var table = ExecuteReader("SELECT slot, level, experience FROM UCE_guild_warehouse_levels WHERE guild=@guild", new SqliteParameter("@guild", player.guild.name));

        if (table.Count > 0)
        {
            foreach (var row in table)
            {
                int slot = Convert.ToInt32((long)row[0]);

                if (slot < player.guildWarehouseStorageItems)
                {
                    Item item = new Item();
					item = player.UCE_guildWarehouse[slot].item;
                    int level = Convert.ToInt32((long)row[1]);
                   	int experience = Convert.ToInt32((long)row[2]);
                    player.UCE_guildWarehouse[slot] = new ItemSlot(item, player.UCE_guildWarehouse[slot].amount, level, experience);
                }
            }
        }
    }
    
    public void SaveGuildWarehouseLevels(Player player)
    {        
		Debug.Log("Saving Guild DB");
		for (int i = 0; i < player.UCE_guildWarehouse.Count; ++i)
			{
				ItemSlot slot = player.UCE_guildWarehouse[i];

				if (slot.amount > 0)
				{
					ExecuteNonQuery("INSERT INTO UCE_guild_warehouse_levels VALUES (@guild, @slot, @level, @experience)",
									new SqliteParameter("@guild", player.guild.name),
									new SqliteParameter("@slot", i),
									new SqliteParameter("@level", slot.level),
									new SqliteParameter("@experience", slot.experience));
			}
		}
	}


}
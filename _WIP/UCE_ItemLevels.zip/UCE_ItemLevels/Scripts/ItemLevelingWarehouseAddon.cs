﻿////////////////////////////////////////////////////////////////////////////////
// Example Addon
//    Author: ...
//
//    Description: ...
//
//    Required Core modifications: ...
//
//    Usage: ...
//
using System.Text;
using System.Collections.Generic;
using UnityEngine;
using Mirror;
using Mono.Data.Sqlite;
using System;
using UnityEngine.UI;
using TMPro;

public partial class Database
{
    void Connect_ItemLevelingWarehouseAddon()
    {
        // it's usually best to create an extra table for your addon. example:
        //ExecuteNonQuery(@"CREATE TABLE IF NOT EXISTS example (
        //                  name TEXT NOT NULL PRIMARY KEY)");

		ExecuteNonQuery(@"CREATE TABLE IF NOT EXISTS 'uce_warehouse_levels' (
                           'character' TEXT NOT NULL,
                           'slot' INTEGER NOT NULL,
                           'level' INTEGER NOT NULL,
                           'experience' INTEGER NOT NULL)");
    }
    void CharacterLoad_ItemLevelingWarehouseAddon(Player player) {
        LoadWarehouseLevels(player);
    }
    void CharacterSave_ItemLevelingWarehouseAddon(Player player) {
        SaveWarehouseLevels(player);
    }

    void LoadWarehouseLevels(Player player)
    {
        List<List<object>> table = ExecuteReader("SELECT slot, level, experience FROM uce_warehouse_levels WHERE character=@character", new SqliteParameter("@character", player.name));
		if (table.Count > 0) {
			foreach (List<object> row in table) {
			
				int slot = Convert.ToInt32((long)row[0]);

				if (slot < player.playerWarehouseStorageItems) {
				ItemSlot temp = new ItemSlot();
                    temp = player.UCE_playerWarehouse[slot];
					int level 	= Convert.ToInt32((long)row[1]);
					int exp = Convert.ToInt32((long)row[2]);
					player.UCE_playerWarehouse[slot] = new ItemSlot(temp.item, temp.amount, level, exp);
				}
			}
		}
    }
    
    void SaveWarehouseLevels(Player player)
    {
		if (player.warehouseActionDone) {
			ExecuteNonQuery("DELETE FROM uce_warehouse_levels WHERE `character`=@character", new SqliteParameter("@character", player.name));

			for (int i = 0; i < player.UCE_playerWarehouse.Count; ++i) {
				ItemSlot slot = player.UCE_playerWarehouse[i];

				if (slot.amount > 0) {
					ExecuteNonQuery("INSERT INTO uce_warehouse_levels VALUES (@character, @slot, @level, @experience)",
									new SqliteParameter("@character", player.name),
									new SqliteParameter("@slot", i),
									new SqliteParameter("@level", slot.level),
									new SqliteParameter("@experience", slot.experience));
				}
			}
		}
    }


}

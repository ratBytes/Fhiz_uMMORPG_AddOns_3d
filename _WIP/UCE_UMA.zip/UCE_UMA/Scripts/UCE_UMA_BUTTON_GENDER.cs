﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UMA;
using UMA.CharacterSystem;
using TMPro;
using System;
using UnityEngine.UI;

public class UCE_UMA_BUTTON_GENDER : MonoBehaviour
{

    public UCE_BUTTON_TYPES type;

    UCE_UMA_CREATOR creator;


    void Start() {
        creator = FindObjectOfType<UCE_UMA_CREATOR>();
        GetComponentInChildren<TextMeshProUGUI>().SetText(type.ToString().Replace("_", " "));

        }

    // Start is called before the first frame update
    public void performTask() {
        if(creator.dca == null) return;
        
        creator.switchGender("Human"+type.ToString());
    }
}

public enum UCE_BUTTON_TYPES {
    Male,
    Female
}

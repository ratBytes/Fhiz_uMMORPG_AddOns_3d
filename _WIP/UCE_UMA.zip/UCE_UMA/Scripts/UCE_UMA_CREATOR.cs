using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UMA;
using UMA.CharacterSystem;
using Mirror;
using System;
using System.Linq;
using UnityEngine.UI;

public class UCE_UMA_CREATOR : UCE_UI_CharacterCreation
{
    [Header("-=-=-=- UMA -=-=-=-")]
    public List<UMATextRecipe> maleHairStyles;
    public List<UMATextRecipe> maleClothing;
    public List<UMATextRecipe> femaleHairStyles;
    public List<UMATextRecipe> femaleClothing;
    
    [HideInInspector]
    public int maleIndex = 0;
    [HideInInspector]
    public int femaleIndex = 0;
    [HideInInspector]
    public int maleClothingIndex = 0;
    [HideInInspector]
    public int femaleClothingIndex = 0;

    [HideInInspector]
    public DynamicCharacterAvatar dca;

    public override void SetCharacterClass(int _classIndex)
    {
        base.SetCharacterClass(_classIndex);
        setupAll();
    }

    public new void Hide() {
        base.Hide();
        dca = null;
    }

    public void setupAll() {
        dca = FindObjectOfType<DynamicCharacterAvatar>();

        StartCoroutine(setup());
    }

    IEnumerator setup()
    {
        yield return new WaitForSeconds(0.1f);
            dca.ChangeRace("HumanMale");
        yield return new WaitForSeconds(0.1f);
            if(maleClothing.Count > 0)
                selectClothing(0);
        yield return new WaitForSeconds(0.1f);
            if(maleHairStyles.Count > 0)
                selectHair(0);
    }

    public void selectClothing(int index)
    {
        bool male = dca.activeRace.name == "HumanMale" ? true : false;
        dca.ClearSlot("Underwear");
            if(male)
                dca.SetSlot(maleClothing[index]);
            if(!male)
                dca.SetSlot(femaleClothing[index]);

                dca.BuildCharacter();
    }

    public void selectHair(int index)
    {
        bool male = dca.activeRace.name == "HumanMale" ? true : false;
        dca.ClearSlot("Hair");

            if(male)
                dca.SetSlot(maleHairStyles[index]);
            if(!male)
                dca.SetSlot(femaleHairStyles[index]);

                dca.BuildCharacter();
    }
    
    public void switchGender(string genderName)
    {
        dca.ChangeRace(genderName);

        if(genderName == "HumanMale")
        {
            if(maleClothing.Count > 0)
                selectClothing(maleClothingIndex);
                
            if(maleHairStyles.Count > 0)
                selectHair(maleIndex);
        }
        if(genderName == "HumanFemale")
        {
            if(femaleClothing.Count > 0)
                selectClothing(femaleClothingIndex);
                
            if(maleHairStyles.Count > 0)
                selectHair(femaleIndex);
        }
    }

    public void changeHairColor(Color col)
    {
        dca.SetColor("Hair", col);
        dca.UpdateColors(true);
    }

    public void changeBaseColor(Color col)
    {
        dca.SetColor("Undies", col);
        dca.UpdateColors(true);
    }

    public void changeEyesColor(Color col)
    {
        dca.SetColor("Eyes", col);
        dca.UpdateColors(true);
    }

    public void changeSkinColor(Color col)
    {
        dca.SetColor("Skin", col);
        dca.UpdateColors(true);
    }

    String compressedString()
    {
        return CompressUMA.Compressor.CompressDna(dca.GetCurrentRecipe());
    }

       // -----------------------------------------------------------------------------------
    // CreateCharacter
    // -----------------------------------------------------------------------------------

    public override void CreateCharacter()
    {
        if (SpawnPoint.transform.childCount > 0)
            Destroy(SpawnPoint.transform.GetChild(0).gameObject);

#if _iMMOTRAITS
        int[] iTraits = new int[traitsPanel.currentTraits.Count];

        for (int i = 0; i < traitsPanel.currentTraits.Count; i++)
        {
            iTraits[i] = traitsPanel.currentTraits[i].name.GetStableHashCode();
        }

        CharacterCreateMsg message = new CharacterCreateMsg
        {
            name = nameInput.text,
            classIndex = classIndex,
            traits = iTraits,
            dna = compressedString()
        };
#else
		CharacterCreateMsg message = new CharacterCreateMsg
        {
            name 		= nameInput.text,
            classIndex 	= classIndex,
            dna = compressedString()
        };

#endif

        NetworkClient.Send(message);

        Hide();
    }
}

﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class UCE_UMA_EDIT_COLORS : MonoBehaviour, IPointerClickHandler
{

    public Color selectedColor;
    public umaColorTypes Category;
    UCE_UMA_CREATOR creator;

    void Start() {
        creator = FindObjectOfType<UCE_UMA_CREATOR>();
        }

    public void OnPointerClick(PointerEventData eventData)
    {
        if(creator.dca == null) return;
        
        selectedColor = GetColor(GetPointerUVPosition());
        switch(Category)
        {
            case umaColorTypes.Skin:
            creator.changeSkinColor(selectedColor);
            break;
            
            case umaColorTypes.Hair:
            creator.changeHairColor(selectedColor);
            break;
            
            case umaColorTypes.Eyes:
            creator.changeEyesColor(selectedColor);
            break;
            
            case umaColorTypes.Base_Clothing:
            creator.changeBaseColor(selectedColor);
            break;
        }
    }

    private Color GetColor(Vector2 pos)
    {
        Texture2D texture = GetComponent<Image>().sprite.texture;
        Color selected = texture.GetPixelBilinear(pos.x, pos.y);
        selected.a = 1; // force full alpha
        return selected;
    }

    Vector2 GetPointerUVPosition()
    {
        Vector3[] imageCorners = new Vector3[4];
        gameObject.GetComponent<RectTransform>().GetWorldCorners(imageCorners);
        float texWidth = imageCorners[2].x - imageCorners[0].x;
        float texHeight = imageCorners[2].y - imageCorners[0].y;
        float uvX = (Input.mousePosition.x - imageCorners[0].x) / texWidth;
        float uvY = (Input.mousePosition.y - imageCorners[0].y) / texHeight;
        return new Vector2(uvX, uvY);
    }
}

public enum umaColorTypes
{
    Skin,
    Eyes,
    Hair,
    Base_Clothing
}
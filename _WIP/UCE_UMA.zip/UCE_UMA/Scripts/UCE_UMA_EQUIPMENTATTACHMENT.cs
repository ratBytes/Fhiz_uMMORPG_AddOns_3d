﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UCE_UMA_EQUIPMENTATTACHMENT : MonoBehaviour
{
    public string attachmentName;
}
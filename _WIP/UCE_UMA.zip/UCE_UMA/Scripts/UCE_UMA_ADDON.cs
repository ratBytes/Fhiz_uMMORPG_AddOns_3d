﻿using System.Text;
using System.Collections.Generic;
using UnityEngine;
using Mirror;
using UMA;
using System.Collections;
using UMA.CharacterSystem;
using System;
using UnityEngine.UI;
using TMPro;
using System.Linq;
using System.IO;
using System.IO.Compression;						// copied from Unity/Mono/lib/mono/2.0 to Plugins

#if _MYSQL
using MySql.Data;								// From MySql.Data.dll in Plugins folder
using MySql.Data.MySqlClient;                   // From MySql.Data.dll in Plugins folder
#elif _SQLITE
using Mono.Data.Sqlite; 
#endif


// entities ////////////////////////////////////////////////////////////////////
public partial class Player
{
    [SyncVar]
    public string umaDna = "";

    void OnStartLocalPlayer_UCE_UMA_ADDON() { StartCoroutine(waitfordcs()); }


    public void updateUMA()
    {
        refreshUMA();
    }
    public void refreshUMA()
    {
            updateEquipment();

        if(Player.localPlayer != this)
            CmdupdateEquipment();

        if(umaDna == "") return;

        Debug.Log(umaDna.ToCharArray().Length);

        DynamicCharacterAvatar avatar = GetComponentInChildren<DynamicCharacterAvatar>();
        
        if(GetComponentInChildren<DynamicCharacterAvatar>() == null) return;

            string decompressed = CompressUMA.Compressor.DecompressDna(umaDna);
            
            avatar.ClearSlots();
                avatar.LoadFromRecipeString(decompressed);

        for(int i = 0; i < equipment.Count; i++) 
        {

        ItemSlot slot = equipment[i];
        EquipmentInfo info = equipmentInfo[i];

            //  valid item?
            if (slot.amount > 0)
            {
            EquipmentItem itemData = (EquipmentItem)slot.item.data;
            
            UMATextRecipe maleRecipe = itemData.maleUmaRecipe;
            UMATextRecipe femaleRecipe = itemData.femaleUmaRecipe;
            
                if(avatar == null) return;
                
                if (maleRecipe != null)
                    avatar.SetSlot(maleRecipe);
                    
                if (femaleRecipe != null)
                    avatar.SetSlot(femaleRecipe);

            }
        }
    }

    IEnumerator waitfordcs()
    {
        yield return new WaitWhile(() => FindObjectOfType<DynamicCharacterSystem>() == null);
        yield return new WaitWhile(() => GetComponentInChildren<DynamicCharacterAvatar>() == null);
        StartCoroutine(waitfordna());
    }
    IEnumerator waitfordna() {
        yield return new WaitWhile(() => umaDna == "");
        refreshUMA();
    }

    [Command]
    public void CmdupdateEquipment()
    {
        RpcupdateEquipment();
    }

    [ClientRpc]
    void RpcupdateEquipment()
    {
        updateEquipment();
    }
    public void updateEquipment()
    {
        GetComponentInChildren<DynamicCharacterAvatar>().Cleanup();
        UCE_UMA_EQUIPMENTATTACHMENT[] attachments = GetComponentsInChildren<UCE_UMA_EQUIPMENTATTACHMENT>();
            for(int i = 0; i < attachments.Length; i++)
            {
                for(int e = 0; e < equipmentInfo.Length; e++)
                {
                    if(equipmentInfo[e].requiredCategory == attachments[i].attachmentName &&
                        equipmentInfo[e].location != attachments[i].transform)
                    {
                        equipmentInfo[e].location = attachments[i].transform;
                        RefreshLocation(e);
                    }
                } 
            }
    }

}
public partial class CharactersAvailableMsg
{
    public partial struct CharacterPreview
    {
        public string umaDna;
    }
    void Load_UCE_UMA_ADDON(List<Player> players)
    {
        for (int i = 0; i < players.Count; ++i)
        {
            characters[i].umaDna = players[i].umaDna;
        }
    }
}

public partial class Database
{
    void Connect_UCE_UMA_ADDON()
    {

        #if _MYSQL
		ExecuteNonQueryMySql(@"CREATE TABLE IF NOT EXISTS uce_uma (
 			'character' VARCHAR(32) NOT NULL,
 			dna VARCHAR(1000) NOT NULL
 		    ) CHARACTER SET=utf8mb4");

        #elif _SQLITE
        ExecuteNonQuery(@"CREATE TABLE IF NOT EXISTS uce_uma (
                            character TEXT NOT NULL,
                            dna TEXT NOT NULL)");
         #endif
    }
    void CharacterLoad_UCE_UMA_ADDON(Player player) { loadUMA(player); }
    void loadUMA(Player player)
    {
        #if _MYSQL
        var table = ExecuteReaderMySql("SELECT dna FROM uce_uma WHERE 'character'=@character", new MySqlParameter("@character", player.name));
		
        #elif _SQLITE
        List< List<object> > table = ExecuteReader("SELECT * FROM uce_uma WHERE character=@character", new SqliteParameter("@character", player.name));
        #endif
        if (table.Count == 1)
        {
            List<object> mainrow = table[0];

                    string tempdna = (string)mainrow[1];
                    player.umaDna = tempdna;
                }
    }
    void CharacterSave_UCE_UMA_ADDON(Player player) { saveUMA(player); }
    void saveUMA(Player player)
    {
    #if _MYSQL
		ExecuteNonQueryMySql("DELETE FROM uce_uma WHERE 'character'=@character", new MySqlParameter("@character", player.name));
			ExecuteNonQueryMySql("INSERT INTO uce_uma VALUES (@character, @dna)",
 				new MySqlParameter("@character", player.name),
 				new MySqlParameter("@dna", player.umaDna));
    #elif _SQLITE
            ExecuteNonQuery("DELETE FROM uce_uma WHERE character=@character", new SqliteParameter("@character", player.name));

            ExecuteNonQuery("INSERT INTO uce_uma VALUES (@character, @dna)",
                new SqliteParameter("@character", player.name),
                new SqliteParameter("@dna", player.umaDna));
    #endif
    }
}

namespace CompressUMA
{
    internal static class Compressor
    {
        /// <summary>
        /// Compresses the string.
        /// </summary>
        /// <param name="text">The text.</param>
        /// <returns></returns>
        public static string CompressDna(string text)
        {
            byte[] buffer = Encoding.UTF8.GetBytes(text);
            var memoryStream = new MemoryStream();
            using (var gZipStream = new GZipStream(memoryStream, CompressionMode.Compress, true))
            {
                gZipStream.Write(buffer, 0, buffer.Length);
            }

            memoryStream.Position = 0;

            var compressedData = new byte[memoryStream.Length];
            memoryStream.Read(compressedData, 0, compressedData.Length);

            var gZipBuffer = new byte[compressedData.Length + 4];
            Buffer.BlockCopy(compressedData, 0, gZipBuffer, 4, compressedData.Length);
            Buffer.BlockCopy(BitConverter.GetBytes(buffer.Length), 0, gZipBuffer, 0, 4);
            return Convert.ToBase64String(gZipBuffer);
        }

        /// <summary>
        /// Decompresses the string.
        /// </summary>
        /// <param name="compressedText">The compressed text.</param>
        /// <returns></returns>
        public static string DecompressDna(string compressedText)
        {
            byte[] gZipBuffer = Convert.FromBase64String(compressedText);
            using (var memoryStream = new MemoryStream())
            {
                int dataLength = BitConverter.ToInt32(gZipBuffer, 0);
                memoryStream.Write(gZipBuffer, 4, gZipBuffer.Length - 4);

                var buffer = new byte[dataLength];

                memoryStream.Position = 0;
                using (var gZipStream = new GZipStream(memoryStream, CompressionMode.Decompress))
                {
                    gZipStream.Read(buffer, 0, buffer.Length);
                }

                return Encoding.UTF8.GetString(buffer);
            }
        }
    }
}
﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;
using UMA;

public class UCE_UMA_BUTTON_CHANGECLOTHING : MonoBehaviour
{
    [Header("Decrease Clothing = false")]
    public bool increase = true;
    public TextMeshProUGUI indexText;
    UCE_UMA_CREATOR creator;

    void Start() {
        creator = FindObjectOfType<UCE_UMA_CREATOR>();
        }
        int index = 0;

    public void changeClothing()
    {
        if(creator.dca == null) return;
        
        bool male = creator.dca.activeRace.name == "HumanMale" ? true : false;
        

        if(male) // Male
        {
            if(increase) // Increase
                if(creator.maleClothingIndex >= creator.maleClothing.Count-1)
                {
                    creator.maleClothingIndex = 0;
                    index = creator.maleClothingIndex;
                }
                else { creator.maleClothingIndex += 1; index = creator.maleClothingIndex; }
            if(!increase) // Decrease
                if(creator.maleClothingIndex == 0)
                {
                    creator.maleClothingIndex = creator.maleClothing.Count-1;
                    index = creator.maleClothingIndex;
                }
                else { creator.maleClothingIndex -= 1; index = creator.maleClothingIndex; }
        }
        if(!male) // Female
        {
            if(increase) // Increase
                if(creator.femaleClothingIndex >= creator.femaleClothing.Count-1)
                {
                    creator.femaleClothingIndex = 0;
                    index = creator.femaleClothingIndex;
                }
                else { creator.femaleClothingIndex += 1; index = creator.femaleClothingIndex; }
            if(!increase) // Decrease
                if(creator.femaleClothingIndex == 0)
                {
                    creator.femaleClothingIndex = creator.femaleClothing.Count-1;
                    index = creator.femaleClothingIndex;
                }
                else { index = creator.femaleClothingIndex; index = creator.femaleClothingIndex; }
        }
        creator.selectClothing(index);

                if(indexText != null)
                    indexText.text = (index+1).ToString();
    }
}
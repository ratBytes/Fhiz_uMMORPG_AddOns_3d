﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;
using UMA;

public class UCE_UMA_BUTTON_HAIRSTYLES : MonoBehaviour
{
    [Header("Decrease Hairstyle = false")]
    public bool increase = true;
    public TextMeshProUGUI indexText;
    UCE_UMA_CREATOR creator;

    void Start() {
        creator = FindObjectOfType<UCE_UMA_CREATOR>();
    }
        int index = 0;

    public void changeHair()
    {
        if(creator.dca == null) return;
        
        bool male = creator.dca.activeRace.name == "HumanMale" ? true : false;
        

        if(male) // Male
        {
            if(increase) // Increase
                if(creator.maleIndex >= creator.maleHairStyles.Count-1)
                {
                    creator.maleIndex = 0;
                    index = creator.maleIndex;
                }
                else { creator.maleIndex += 1; index = creator.maleIndex; }
            if(!increase) // Decrease
                if(creator.maleIndex == 0)
                {
                    creator.maleIndex = creator.maleHairStyles.Count-1;
                    index = creator.maleIndex;
                }
                else { creator.maleIndex -= 1; index = creator.maleIndex; }
        }
        if(!male) // Female
        {
            if(increase) // Increase
                if(creator.femaleIndex >= creator.femaleHairStyles.Count-1)
                {
                    creator.femaleIndex = 0;
                    index = creator.femaleIndex;
                }
                else { creator.femaleIndex += 1; index = creator.femaleIndex; }
            if(!increase) // Decrease
                if(creator.femaleIndex == 0)
                {
                    creator.femaleIndex = creator.femaleHairStyles.Count-1;
                    index = creator.femaleIndex;
                }
                else { creator.femaleIndex -= 1; index = creator.femaleIndex; }
        }
        creator.selectHair(index);

                if(indexText != null)
                    indexText.text = (index+1).ToString();
    }
}
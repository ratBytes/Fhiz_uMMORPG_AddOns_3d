﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;
using UMA;

public class UCE_UMA_BUTTON_HAIRSTYLE : MonoBehaviour
{
    public int MaleHairStyleIndex = 0;
    public int FemaleHairStyleIndex = 0;
    public TextMeshProUGUI indexText;
    UCE_UMA_CREATOR creator;

    void Start() {
        creator = FindObjectOfType<UCE_UMA_CREATOR>();
    }

    public void changeHair()
    {
        if(creator.dca == null) return;
        
        bool male = creator.dca.activeRace.name == "HumanMale" ? true : false;

        creator.selectHair(male ? MaleHairStyleIndex : FemaleHairStyleIndex);

                if(indexText != null)
                    indexText.text = ((male ? MaleHairStyleIndex : FemaleHairStyleIndex)+1).ToString();
    }
}
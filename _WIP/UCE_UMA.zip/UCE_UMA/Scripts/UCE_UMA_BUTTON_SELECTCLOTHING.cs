﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;
using UMA;

public class UCE_UMA_BUTTON_SELECTCLOTHING : MonoBehaviour
{
    public int MaleClothingIndex = 0;
    public int FemaleClothingIndex = 0;
    public TextMeshProUGUI indexText;
    UCE_UMA_CREATOR creator;

    void Start() {
        creator = FindObjectOfType<UCE_UMA_CREATOR>();
        }
        
    public void changeClothing()
    {
        if(creator.dca == null) return;
        
        bool male = creator.dca.activeRace.name == "HumanMale" ? true : false;
        
        creator.selectClothing(male ? MaleClothingIndex : FemaleClothingIndex);
        
                if(indexText != null)
                    indexText.text = male ? (MaleClothingIndex+1).ToString() : (FemaleClothingIndex+1).ToString();
    }
}